﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Text;
using System.Threading;
using OpenCvSharp;
using System.IO;
using System.Diagnostics;
using System.Drawing.Imaging;
using System.Runtime.Remoting.Channels;

namespace CapColor
{
    public partial class Form1 : Form
    {
        PrivateFontCollection Arcade = new PrivateFontCollection(); //외부 폰트 사용하기 위한 선언  www.dafont.com
        public class Contour
        {
            public int count;
            public CvPoint[] point;
            public CvRect rect;
            public CvPoint senter;
            public Contour()
            {
                point = new CvPoint[200];
                count = 0;
            }
            public Contour(int size)
            {
                point = new CvPoint[size];
                count = 0;
            }
            public Contour(CvPoint _point)
            {
                point = new CvPoint[200];
                point[0] = _point;
                count = 1;
            }
            public Contour(int size, CvPoint _point)
            {
                point = new CvPoint[size];
                point[0] = _point;
                count = 1;
            }
        }
        public class Contours
        {
            public Contour[] contour;   //꼭지점의 좌표들과 갯수 저장
            public int num;             //꼭지점 갯수
            public int path;            //꼭지점을 찾기위한 범위 설정
            public int Pointsize;
            public Contours()
            {
                num = 0;
                contour = new Contour[100];
                path = 2;
            }
            public Contours(int _Pointsize)
            {
                num = 0;
                contour = new Contour[_Pointsize];
                Pointsize = _Pointsize;
                path = 2;
            }

            public void Add(CvPoint point)
            {
                int x, y;
                bool add = false;
                int cot;
                for (int i = 0; i < num; i++)
                {
                    cot = contour[i].count;
                    for (int j = 0; j < cot; j++)
                    {
                        if (contour[i].count != 0)
                        {
                            x = contour[i].point[j].X - point.X;
                            y = contour[i].point[j].Y - point.Y;
                            if ((x <= path && x >= -path) && (y <= path && y >= -path))
                            {
                                contour[i].point[contour[i].count].X = point.X;
                                contour[i].point[contour[i].count].Y = point.Y;                                
                                contour[i].count++;
                                add = true;
                                j = contour[i].count;
                                i+= num;                                
                            }
                        }
                        else
                        {
                            j = contour[i].count;
                        }
                    }
                }

                if (add == false)
                {
                    contour[num] = new Contour(Pointsize,point);		
                    num++;
                }
            }
            protected bool RectOverlap(CvRect rect1, CvRect rect2)
            {
                if (rect1.X >= rect2.X - 1 && rect1.X <= rect2.X + rect2.Width + 1)
                {
                    if (rect1.Y >= rect2.Y - 1 && rect1.Y <= rect2.Y + rect2.Height + 1)
                        return true;
                }

                if (rect1.X + rect1.Width >= rect2.X - 1 && rect1.X + rect1.Width <= rect2.X + rect2.Width + 1)
                {
                    if (rect1.Y + rect1.Height >= rect2.Y - 1 && rect1.Y + rect1.Height <= rect2.Y + rect2.Height + 1)
                        return true;
                }

                if (rect1.X >= rect2.X - 1 && rect1.X <= rect2.X + rect2.Width + 1)
                {
                    if (rect1.Y + rect1.Height >= rect2.Y - 1 && rect1.Y + rect1.Height <= rect2.Y + rect2.Height + 1)
                        return true;
                }

                if (rect1.X + rect1.Width >= rect2.X - 1 && rect1.X + rect1.Width <= rect2.X + rect2.Width + 1)
                {
                    if (rect1.Y >= rect2.Y - 1 && rect1.Y <= rect2.Y + rect2.Height + 1)
                        return true;
                }

                return false;
            }
            public void Sort()
            {
                for (int i = 0; i < num; i++)
                {
                    contour[i].rect.X = 20000;
                    contour[i].rect.Y = 20000;
                    for (int j = 0; j < contour[i].count; j++)
                    {
                        if (contour[i].point[j].X < contour[i].rect.X)
                            contour[i].rect.X = contour[i].point[j].X;

                        if (contour[i].point[j].Y < contour[i].rect.Y)
                            contour[i].rect.Y = contour[i].point[j].Y;
                    }
                }

                for (int i = 0; i < num; i++)
                {
                    contour[i].rect.Width = 0;
                    contour[i].rect.Height = 0;
                    for (int j = 0; j < contour[i].count; j++)
                    {
                        if (contour[i].point[j].X > contour[i].rect.Width)
                            contour[i].rect.Width = contour[i].point[j].X;

                        if (contour[i].point[j].Y > contour[i].rect.Height)
                            contour[i].rect.Height = contour[i].point[j].Y;
                    }
                    contour[i].rect.Width -= contour[i].rect.X;
                    contour[i].rect.Height -= contour[i].rect.Y;
                }

                int x, y;
                int Renum = num;
                int cout1, cout2;
                for (int i = 0; i < num; i++)
                {
                    for (int j = 0; j < num; j++)
                    {
                        if (contour[j].count != 0)
                        {//해당 칸에 존재하는 좌표가 없음

                            if (i != j)
                            {//같은 영역은 비교할 필요 없음
                                if (RectOverlap(contour[i].rect, contour[j].rect))
                                {//영역이 서로 인접할 경우 비교 검사
                                    cout1 = contour[i].count;
                                    cout2 = contour[j].count;
                                    for (int l = 0; l < cout1; l++)
                                    {
                                        for (int k = 0; k < cout2; k++)
                                        {
                                            //좌표 하나하나마다 비교하여 인접하는지의 수치를 x,y에 저장
                                            x = contour[i].point[l].X - contour[j].point[k].X;
                                            y = contour[i].point[l].Y - contour[j].point[k].Y;

                                            if ((x <= 1 && x >= -1) && (y <= 1 && y >= -1))
                                            {//차이가 1이하일 경우는 인접한것으로 판단
                                                for (int p = 0; p < cout2; p++)
                                                {//기존의 i번째 영역에 j번째 좌표를 저장함
                                                    contour[i].point[contour[i].count + p].X = contour[j].point[p].X;
                                                    contour[i].point[contour[i].count + p].Y = contour[j].point[p].Y;
                                                }
                                                l = contour[i].count + 1;   //for 종료
                                                k = contour[j].count + 1;   //for 종료
                                                contour[i].count += contour[j].count;
                                                contour[j].count = 0;		//j영역을 비움										
                                                Renum--;
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }
                }
                Contour[] contours = new Contour[Renum];
                int count = 0;
                for (int i = 0; i < num; i++)
                {
                    if (contour[i].count != 0)
                    {
                        contours[count] = new Contour();
                        contours[count].point = new CvPoint[contour[i].count];
                        contours[count].count = contour[i].count;
                        contours[count].rect = contour[i].rect;
                        contours[count].senter.X = 0;// contour[i].rect.X + contour[i].rect.Width / 2;//contour[i].point[contour[i].count / 2].X;// 
                        contours[count].senter.Y = 0;// contour[i].rect.Y + contour[i].rect.Height / 2;//contour[i].point[contour[i].count / 2].Y;//

                        for (int j = 0; j < contour[i].count; j++)
                        {
                            contours[count].senter.X += contour[i].point[j].X;
                            contours[count].senter.Y += contour[i].point[j].Y;
                            contours[count].point[j].X = contour[i].point[j].X;
                            contours[count].point[j].Y = contour[i].point[j].Y;
                        }
                        contours[count].senter.X /= contour[i].count;
                        contours[count].senter.Y /= contour[i].count;

                        count++;
                    }
                }
                contour = contours;
                num = Renum;
            }
        }
        public struct PCBInfo
        {
            public int X, Y;//중심
            public int Width, Height;//가로 세로
            public double Area, Length;//넓이 둘레
            public CvPoint Center;
            
        }
        public struct PCBtestInfo
        {
            public int X, Y;
            public double Degree;
        }

        //Ref 영역 정보//  X,Y, 가로,세로 넓이 둘레
        PCBInfo ContourInfo;                
        PCBInfo[] HolderInfo, CircleInfo;
        //Ref 영역 정보//
        
        //Ref 세부 정보// X,Y ,각도
        PCBtestInfo[] ContourInfo2;
        PCBtestInfo[][] HolderInfo2;
        //Ref 세부 정보//
        
        //각 PCB영역 갯수
        int PCBtotla, HolderCount,CircleCount;
        int PCBtotla2, HolderCount2;
        //각 PCB영역 갯수

        IplImage[] src,dst;        
        CvFont font;
        IplImage gray, Feature_gray, PCB, Holder;
        Image image;
        Stopwatch sw;
        Bitmap bmp;
        BitmapData bmpData;
        string[] asb,asb2;
        int count = 0;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {          
            sw = new Stopwatch();
            LoadInfo();
        }        
        private void Button_Open(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "All |*.*|JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.Multiselect = true;
            
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                sw.Start();
                //여러개의 이미지를 한꺼번에 불러올 수 있음 (1개도 가능)
                asb = openFileDialog1.FileNames;                
                asb2 = openFileDialog1.SafeFileNames;
                count = openFileDialog1.SafeFileNames.Length;
                src = new IplImage[count];                
                for (int i = 0; i < count; i++)
                {          
                    //Image형으로 불러오기
                    image = Image.FromFile(asb[i]);
                    pictureBox1.Image = image;  
                    
                    //Image형을 IplImage형으로 변환하기 위한 중간 과정
                    bmp = new Bitmap(image);
                    bmpData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite,PixelFormat.Format24bppRgb);
                    src[i] = Cv.CreateImage(Cv.Size(image.Width, image.Height), BitDepth.U8, 3); //불러온 이미지 크기에 맞게 IplImage형 선언
                    src[i].CopyPixelData(bmpData.Scan0);               
                    //불러온 경로의 이름뒤에 .bmp때기
                    asb2[i]=asb2[i].Replace(".bmp", " ");
                    //창이름에 띄우기
                    this.Text = asb2[i];
                }
                gray = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                Feature_gray = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                PCB = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                Holder = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                sw.Stop();
                MessageBox.Show(sw.ElapsedMilliseconds.ToString() + "ms");
                sw.Reset();
            }
        }
        private void Button_Save(object sender, EventArgs e)
        {
            if (gray != null)
            {
                saveFileDialog1.Filter = "All |*.*|JPEG Image|*.jpg|Bitmap Image|*.bmp|GIF Image|*.gif|PNG Image|*.png";
                saveFileDialog1.Title = "Save an Image File";
                saveFileDialog1.FilterIndex = 0;
                saveFileDialog1.DefaultExt = "bmp";
                saveFileDialog1.RestoreDirectory = true;
                saveFileDialog1.FileName = this.Text;
                if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string asb = saveFileDialog1.FileName;
                    pictureBox1.Image.Save(asb);
                }
            }
        }

        //////////////////////////////////////////검사를 위해 사용하는 함수//////////////////////////////////////////
        public IplImage smalls(IplImage img_in, double size)
        {
            IplImage img_out = Cv.CloneImage(img_in);  // return image
            CvMemStorage storage = Cv.CreateMemStorage(0);    // container of retrieved contours
            CvSeq<CvPoint> contours;
            double area;
            CvRect rect;
            Cv.FindContours(img_out, storage, out contours, CvContour.SizeOf, ContourRetrieval.List, ContourChain.ApproxSimple, new CvPoint(0, 0));
            while (contours != null)   // loop over all the contours
            {
                area = Math.Abs(Cv.ContourArea(contours, Cv.WHOLE_SEQ));
                rect = Cv.BoundingRect(contours);
                if (rect.Height <= size && rect.Width <= size)  // if the area of the contour is less than threshold remove it
                {
                    // draws the contours into a new image
                    if (Math.Abs(area) <= size * size / 2)
                        Cv.DrawContours(img_in, contours, new CvScalar(0), new CvScalar(0), -1, -1);
                }
                contours = contours.HNext;    // jump to the next contour
            }
            Cv.ReleaseMemStorage(storage);
            return img_in;
        }                  //크기가 작은 부분삭제후 이미지 반환
        public double getColor(IplImage src)
        {
            CvScalar judg = Cv.Avg(src);
            IplImage gray = Cv.CreateImage(Cv.GetSize(src), src.Depth, 1);
            Cv.Threshold(src, gray, judg.Val0, 255, ThresholdType.ToZero);
            int count = Cv.CountNonZero(gray);
            CvScalar cc = Cv.Avg(gray);
            return (cc.Val0 * src.Width * src.Height) / count;
        }                                      //평균색상에서의 평균색상값 반환
        public CvPoint[] Findstraight(CvRect rect, CvBox2D rect2)
        {
            CvPoint[] points = new CvPoint[4];
            //랜덤으로 구해지는 4개의 좌표에서 PCB의 왼쪽 윗부분에 가까운 부분을 찾아 좌표 설정
            if ((int)rect2.BoxPoints()[2].Y > gray.Height / 2) //Math.Max(pcvrect2.Size.Width, pcvrect2.Size.Height) == pcvrect2.Size.Width)
            {
                if ((int)rect2.BoxPoints()[2].X > gray.Width / 2)
                {
                    //2341
                    if (rect.Width > rect.Height)
                    {
                        points[0].X = (int)rect2.BoxPoints()[1].X;
                        points[0].Y = (int)rect2.BoxPoints()[1].Y;
                        points[1].X = (int)rect2.BoxPoints()[2].X;
                        points[1].Y = (int)rect2.BoxPoints()[2].Y;
                        points[2].X = (int)rect2.BoxPoints()[3].X;
                        points[2].Y = (int)rect2.BoxPoints()[3].Y;
                        points[3].X = (int)rect2.BoxPoints()[0].X;
                        points[3].Y = (int)rect2.BoxPoints()[0].Y;
                    }
                    else
                    {
                        points[0].X = (int)rect2.BoxPoints()[2].X;
                        points[0].Y = (int)rect2.BoxPoints()[2].Y;
                        points[1].X = (int)rect2.BoxPoints()[3].X;
                        points[1].Y = (int)rect2.BoxPoints()[3].Y;
                        points[2].X = (int)rect2.BoxPoints()[0].X;
                        points[2].Y = (int)rect2.BoxPoints()[0].Y;
                        points[3].X = (int)rect2.BoxPoints()[1].X;
                        points[3].Y = (int)rect2.BoxPoints()[1].Y;
                    }
                }
                else
                {
                    //3412
                    if (rect.Width > rect.Height)
                    {
                        points[0].X = (int)rect2.BoxPoints()[2].X;
                        points[0].Y = (int)rect2.BoxPoints()[2].Y;
                        points[1].X = (int)rect2.BoxPoints()[3].X;
                        points[1].Y = (int)rect2.BoxPoints()[3].Y;
                        points[2].X = (int)rect2.BoxPoints()[0].X;
                        points[2].Y = (int)rect2.BoxPoints()[0].Y;
                        points[3].X = (int)rect2.BoxPoints()[1].X;
                        points[3].Y = (int)rect2.BoxPoints()[1].Y;
                    }
                    else
                    {
                        points[0].X = (int)rect2.BoxPoints()[3].X;
                        points[0].Y = (int)rect2.BoxPoints()[3].Y;
                        points[1].X = (int)rect2.BoxPoints()[0].X;
                        points[1].Y = (int)rect2.BoxPoints()[0].Y;
                        points[2].X = (int)rect2.BoxPoints()[1].X;
                        points[2].Y = (int)rect2.BoxPoints()[1].Y;
                        points[3].X = (int)rect2.BoxPoints()[2].X;
                        points[3].Y = (int)rect2.BoxPoints()[2].Y;
                    }
                }
            }
            else
            {
                if ((int)rect2.BoxPoints()[2].X > gray.Width / 2)
                {
                    //3412
                    if (rect.Width > rect.Height)
                    {
                        points[0].X = (int)rect2.BoxPoints()[1].X;
                        points[0].Y = (int)rect2.BoxPoints()[1].Y;
                        points[1].X = (int)rect2.BoxPoints()[2].X;
                        points[1].Y = (int)rect2.BoxPoints()[2].Y;
                        points[2].X = (int)rect2.BoxPoints()[3].X;
                        points[2].Y = (int)rect2.BoxPoints()[3].Y;
                        points[3].X = (int)rect2.BoxPoints()[0].X;
                        points[3].Y = (int)rect2.BoxPoints()[0].Y;
                    }
                    else
                    {
                        points[0].X = (int)rect2.BoxPoints()[2].X;
                        points[0].Y = (int)rect2.BoxPoints()[2].Y;
                        points[1].X = (int)rect2.BoxPoints()[3].X;
                        points[1].Y = (int)rect2.BoxPoints()[3].Y;
                        points[2].X = (int)rect2.BoxPoints()[0].X;
                        points[2].Y = (int)rect2.BoxPoints()[0].Y;
                        points[3].X = (int)rect2.BoxPoints()[1].X;
                        points[3].Y = (int)rect2.BoxPoints()[1].Y;
                    }
                }
                else
                {
                    //4123
                    if (rect.Width > rect.Height)
                    {
                        points[0].X = (int)rect2.BoxPoints()[2].X;
                        points[0].Y = (int)rect2.BoxPoints()[2].Y;
                        points[1].X = (int)rect2.BoxPoints()[3].X;
                        points[1].Y = (int)rect2.BoxPoints()[3].Y;
                        points[2].X = (int)rect2.BoxPoints()[0].X;
                        points[2].Y = (int)rect2.BoxPoints()[0].Y;
                        points[3].X = (int)rect2.BoxPoints()[1].X;
                        points[3].Y = (int)rect2.BoxPoints()[1].Y;
                    }
                    else
                    {
                        points[0].X = (int)rect2.BoxPoints()[3].X;
                        points[0].Y = (int)rect2.BoxPoints()[3].Y;
                        points[1].X = (int)rect2.BoxPoints()[0].X;
                        points[1].Y = (int)rect2.BoxPoints()[0].Y;
                        points[2].X = (int)rect2.BoxPoints()[1].X;
                        points[2].Y = (int)rect2.BoxPoints()[1].Y;
                        points[3].X = (int)rect2.BoxPoints()[2].X;
                        points[3].Y = (int)rect2.BoxPoints()[2].Y;
                    }
                }
            }

            return points;
        }              //PCB 외각영역 좌표순서 검색후 반환
        public PCBtestInfo[] Inspection(CvPoint[] point, int N, double sigma)
        {
            if (N < point.Length)
            {      
                //////////////////////직선인 성질을 띤 점만 제거//////////////////////
                int Length = point.Length;
                int iddle = 0;
                CvPoint[] line = new CvPoint[Length];    
                //거리 변수
                double right, left, middle;
                for (int i = 0; i < Length; i++)
                {
                    //A-B-C 의 점에서 A-B길이와 B-C길이와 A-C길이를 구하여 차이가 많이 나는 부분을 line변수에 저장함.
                    right = left = middle = 0;
                    if (i - N / 2 < 0)
                    {
                        right = Math.Sqrt(Math.Pow(point[i - N / 2 + Length - 1].X - point[i].X, 2) + Math.Pow(point[i - N / 2 + Length - 1].Y - point[i].Y, 2));
                        left = Math.Sqrt(Math.Pow(point[i].X - point[i + N / 2].X, 2) + Math.Pow(point[i].Y - point[i + N / 2].Y, 2));
                        middle = Math.Sqrt(Math.Pow(point[i - N / 2 + Length - 1].X - point[i + N / 2].X, 2) + Math.Pow(point[i - N / 2 + Length - 1].Y - point[i + N / 2].Y, 2));
                    }
                    else
                    {
                        right = Math.Sqrt(Math.Pow(point[i - N / 2].X - point[i].X, 2) + Math.Pow(point[i - N / 2].Y - point[i].Y, 2));
                        if (i + N / 2 > point.Length - 1)
                        {
                            left = Math.Sqrt(Math.Pow(point[i].X - point[i + N / 2 - Length + 1].X, 2) + Math.Pow(point[i].Y - point[i + N / 2 - Length + 1].Y, 2));
                            middle = Math.Sqrt(Math.Pow(point[i - N / 2].X - point[i + N / 2 - Length + 1].X, 2) + Math.Pow(point[i - N / 2].Y - point[i + N / 2 - Length + 1].Y, 2));
                        }
                        else
                        {
                            left = Math.Sqrt(Math.Pow(point[i].X - point[i + N / 2].X, 2) + Math.Pow(point[i].Y - point[i + N / 2].Y, 2));
                            middle = Math.Sqrt(Math.Pow(point[i - N / 2].X - point[i + N / 2].X, 2) + Math.Pow(point[i - N / 2].Y - point[i + N / 2].Y, 2));
                        }
                    }

                    if (right + left - middle > sigma)
                    {
                        line[iddle] = point[i];
                        iddle++;
                    }
                }
                //////////////////////직선인 성질을 띤 점만 제거//////////////////////

                //////////////////////////인접한 점끼리 뭉침/////////////////////////////
                Contours contour = new Contours(iddle);                
                for (int i = 0; i < iddle; i++)
                {
                    contour.Add(line[i]);
                }
                contour.Sort();
                CvPoint[] pp = new CvPoint[contour.num];
                for (int i = 0; i < contour.num; i++)
                {
                    pp[i] = contour.contour[i].senter;
                }
                //////////////////////////인접한 점끼리 뭉침/////////////////////////////


                ///////////////////////각도가 15'이상인 성분만 남김//////////////////////
                int x1, x2, y1, y2;
                Length = contour.num;
                PCBtestInfo[] Pcbtextinfo = new PCBtestInfo[1];
                if (Length > 2)
                {
                    
                    iddle = 0;                    
                    for (int i = 0; i < Length; i++)
                    {
                        if (i - 1 < 0)
                        {
                            x1 = pp[i - 1 + Length].X - pp[i].X;
                            y1 = pp[i - 1 + Length].Y - pp[i].Y;
                            x2 = pp[i + 1].X - pp[i].X;
                            y2 = pp[i + 1].Y - pp[i].Y;
                            middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                        }
                        else
                        {
                            x1 = pp[i - 1].X - pp[i].X;
                            y1 = pp[i - 1].Y - pp[i].Y;

                            if (i + 1 > Length - 1)
                            {
                                x2 = pp[i + 1 - Length].X - pp[i].X;
                                y2 = pp[i + 1 - Length].Y - pp[i].Y;
                                middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                            }
                            else
                            {
                                x2 = pp[i + 1].X - pp[i].X;
                                y2 = pp[i + 1].Y - pp[i].Y;
                                middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                            }
                        }
                        middle = ((middle * 180.0) / 3.141592);

                        if (Math.Abs(middle) > 15.0) 
                        {
                            point[iddle] = pp[i];
                            iddle++;
                        }
                    }
                    pp = new CvPoint[iddle];                    
                    for (int i = 0; i < iddle; i++) pp[i] = point[i];

                    Length = iddle;
                    Pcbtextinfo = new PCBtestInfo[iddle];
                    iddle=0;
                    for (int i = 0; i < Length; i++)
                    {
                        if (i - 1 < 0)
                        {
                            x1 = pp[i - 1 + Length].X - pp[i].X;
                            y1 = pp[i - 1 + Length].Y - pp[i].Y;
                            x2 = pp[i + 1].X - pp[i].X;
                            y2 = pp[i + 1].Y - pp[i].Y;
                            middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                        }
                        else
                        {
                            x1 = pp[i - 1].X - pp[i].X;
                            y1 = pp[i - 1].Y - pp[i].Y;

                            if (i + 1 > Length - 1)
                            {
                                x2 = pp[i + 1 - Length].X - pp[i].X;
                                y2 = pp[i + 1 - Length].Y - pp[i].Y;
                                middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                            }
                            else
                            {
                                x2 = pp[i + 1].X - pp[i].X;
                                y2 = pp[i + 1].Y - pp[i].Y;
                                middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                            }
                        }
                        middle = ((middle * 180.0) / 3.141592);

                        if (Math.Abs(middle) > 15.0)
                        {
                            Pcbtextinfo[iddle].X = pp[i].X;
                            Pcbtextinfo[iddle].Y = pp[i].Y;
                            Pcbtextinfo[iddle].Degree = Math.Abs(middle);
                            iddle++;
                        }
                    }
                    ///////////////////////각도가 15'이상인 성분만 남김//////////////////////
                    
                    
                    //////////////최종 정렬부분//////////인접한 각도끼리 뭉쳐줌//////////////                        
                    int k = iddle;
                    for (int i = 0; i < iddle; i++)
                    {
                        for (int j = 0; j < iddle; j++)
                        {
                            if (i != j)
                            {
                                if (Pcbtextinfo[j].X != 0 && Math.Abs(Pcbtextinfo[i].X - Pcbtextinfo[j].X) < N - 5 && Math.Abs(Pcbtextinfo[i].Y - Pcbtextinfo[j].Y) < N - 5 && Math.Abs(i - j) < 3 && Pcbtextinfo[i].Degree + Pcbtextinfo[j].Degree<105.0)
                                {
                                    if (Pcbtextinfo[i].Degree > Pcbtextinfo[j].Degree)
                                    {
                                        Pcbtextinfo[i].Degree += Pcbtextinfo[j].Degree;
                                        Pcbtextinfo[j].X = 0;
                                        Pcbtextinfo[j].Y = 0;
                                        Pcbtextinfo[j].Degree = 0;
                                    }
                                    else
                                    {
                                        Pcbtextinfo[j].Degree += Pcbtextinfo[i].Degree;
                                        Pcbtextinfo[i].X = 0;
                                        Pcbtextinfo[i].Y = 0;
                                        Pcbtextinfo[i].Degree = 0;
                                    }
                                    k--;
                                }
                            }
                        }
                    }                    
                    PCBtestInfo[] Pcbtextinfo2 = new PCBtestInfo[k];
                    k = 0;
                    for (int i = 0; i < iddle; i++)
                    {                        
                        if (Pcbtextinfo[i].X != 0)
                        {
                            Pcbtextinfo2[k].X = Pcbtextinfo[i].X;
                            Pcbtextinfo2[k].Y = Pcbtextinfo[i].Y;
                            Pcbtextinfo2[k].Degree = Pcbtextinfo[i].Degree;
                            //if (Pcbtextinfo[k].Degree > 90) Pcbtextinfo[k].Degree -= 90.0;
                            k++;
                        }
                    }
                    //////////////최종 정렬부분//////////인접한 각도끼리 뭉쳐줌//////////////

                    
                    Length = k;
                    iddle = 0;
                    Pcbtextinfo = new PCBtestInfo[k];
                    for (int i = 0; i < Length; i++)
                    {
                        if (i - 1 < 0)
                        {
                            x1 = Pcbtextinfo2[i - 1 + Length].X - Pcbtextinfo2[i].X;
                            y1 = Pcbtextinfo2[i - 1 + Length].Y - Pcbtextinfo2[i].Y;
                            x2 = Pcbtextinfo2[i + 1].X - Pcbtextinfo2[i].X;
                            y2 = Pcbtextinfo2[i + 1].Y - Pcbtextinfo2[i].Y;
                            middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                        }
                        else
                        {
                            x1 = Pcbtextinfo2[i - 1].X - Pcbtextinfo2[i].X;
                            y1 = Pcbtextinfo2[i - 1].Y - Pcbtextinfo2[i].Y;

                            if (i + 1 > Length - 1)
                            {
                                x2 = Pcbtextinfo2[i + 1 - Length].X - Pcbtextinfo2[i].X;
                                y2 = Pcbtextinfo2[i + 1 - Length].Y - Pcbtextinfo2[i].Y;
                                middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                            }
                            else
                            {
                                x2 = Pcbtextinfo2[i + 1].X - Pcbtextinfo2[i].X;
                                y2 = Pcbtextinfo2[i + 1].Y - Pcbtextinfo2[i].Y;
                                middle = Math.Asin((x1 * y2 - y1 * x2) / (Math.Sqrt(x1 * x1 + y1 * y1) * Math.Sqrt(x2 * x2 + y2 * y2)));
                            }
                        }
                        middle = ((middle * 180.0) / 3.141592);

                        if (Math.Abs(middle) > 15.0)
                        {
                            Pcbtextinfo[iddle].X = Pcbtextinfo2[i].X;
                            Pcbtextinfo[iddle].Y = Pcbtextinfo2[i].Y;
                            Pcbtextinfo[iddle].Degree = Math.Abs(middle);
                            iddle++;
                        }
                    }
                    Pcbtextinfo2 = new PCBtestInfo[iddle];
                    k = 0;
                    for (int i = 0; i < iddle; i++)
                    {
                        if (Pcbtextinfo[i].X != 0)
                        {
                            Pcbtextinfo2[k].X = Pcbtextinfo[i].X;
                            Pcbtextinfo2[k].Y = Pcbtextinfo[i].Y;
                            Pcbtextinfo2[k].Degree = Pcbtextinfo[i].Degree;
                            //if (Pcbtextinfo[k].Degree > 90) Pcbtextinfo[k].Degree -= 90.0;
                            k++;
                        }
                    }
                                        
                    return Pcbtextinfo2;
                }
                else
                {
                    ///////좌표의 갯수가 1개 이하이므로 0을 반환해줌//////
                    Pcbtextinfo = new PCBtestInfo[Length];
                    Pcbtextinfo[0].X = contour.contour[0].senter.X;
                    Pcbtextinfo[0].Y = contour.contour[0].senter.Y;
                    Pcbtextinfo[0].Degree = 0;
                    ///////좌표의 갯수가 1개 이하이므로 0을 반환해줌//////
                    return Pcbtextinfo;
                }                
            }
            else
            {
                return null;
            }
        }         //Holder영역의 각도정보 반환
        public int getPattern(CvPoint[] point, CvRect rect)
        {
            if (rect.X >= point[0].X && rect.X + rect.Width <= point[1].X && rect.Y >= point[0].Y && rect.Y + rect.Height <= point[3].Y)
            {
                return HolderFind(rect);
            }
            else
                return -1;
        }                             //Holder영역 정보숫자 반환
        public IplImage Transrate(IplImage src, int width, int height)
        {
            IplImage dst = Cv.CreateImage(Cv.GetSize(src), src.Depth, src.NChannels);
            if (src.NChannels == 3)
            {
                unsafe
                {
                    width = src.Width / 2 - width;
                    height = src.Height / 2 - height;                    
                    for (int h = 0; h < gray.Height; h++)
                    {
                        for (int w = 0; w < gray.Width; w++)
                        {
                            if (h - height < src.Height && h - height >= 0 && w - width < src.WidthStep && w - width >= 0)
                            {
                                dst.ImageDataPtr[h * src.WidthStep + w * 3] = src.ImageDataPtr[(h - height) * src.WidthStep + (w - width) * 3];
                                dst.ImageDataPtr[h * src.WidthStep + w * 3 + 1] = src.ImageDataPtr[(h - height) * src.WidthStep + (w - width) * 3 + 1];
                                dst.ImageDataPtr[h * src.WidthStep + w * 3 + 2] = src.ImageDataPtr[(h - height) * src.WidthStep + (w - width) * 3 + 2];
                            }
                        }
                    }
                }
            }
            else if (src.NChannels == 1)
            {
                unsafe
                {
                    height = src.Height / 2 - height;
                    width = src.Width / 2 - width;
                    for (int h = 0; h < gray.Height; h++)
                    {
                        for (int w = 0; w < gray.Width; w++)
                        {
                            if (h - height < src.Height && h - height >= 0 && w - width < src.WidthStep && w - width >= 0)
                            {
                                dst.ImageDataPtr[h * src.WidthStep + w] = src.ImageDataPtr[(h - height) * src.WidthStep + (w - width)];
                            }
                        }
                    }
                }
            }
            return dst;
        }           //PCB를 화면 중심으로 이동후 반환
        private int HolderFind(CvRect rect)
        {
            if (PCBtotla == -1 || HolderCount == -1 || CircleCount == -1)
            {
                if (rect.X < 650) //Left
                {
                    if (rect.Y > 750 && rect.Y + rect.Height < 960) //top
                        return 0;
                    else if (rect.Y > 890 && rect.Y + rect.Height < 1280) //middle
                    {
                        if (rect.X > 550) return 12;
                        else return 1;
                    }
                    else if (rect.Y > 1220 && rect.Y + rect.Height < 1560) //bottom
                        return 2;
                    else return -1;

                }
                else if (rect.X > 1860) //Right
                {
                    if (rect.Y > 750 && rect.Y + rect.Height < 960) //top
                        return 3;
                    else if (rect.Y > 890 && rect.Y + rect.Height < 1280) //middle
                    {
                        if (rect.X > 1980)
                            return 4;
                        else return 13;
                    }
                    else if (rect.Y > 1220 && rect.Y + rect.Height < 1560) //bottom
                        return 5;
                    else return -1;

                }
                else if (rect.Y > 1080 && rect.Y + rect.Height < 1330) //Middle
                {
                    if (rect.X > 650 && rect.X + rect.Width < 860) return 6;
                    else if (rect.X > 930 && rect.X + rect.Width < 1050) return 7;
                    else if (rect.X > 1140 && rect.X + rect.Width < 1250) return 8;
                    else if (rect.X > 1330 && rect.X + rect.Width < 1450) return 9;
                    else if (rect.X > 1530 && rect.X + rect.Width < 1650) return 10;
                    else if (rect.X > 1730 && rect.X + rect.Width < 1930) return 11;
                }
            }
            else
            {
                int left = Math.Min(Math.Min(HolderInfo[0].X, HolderInfo[1].X), HolderInfo[2].X);
                int Right = Math.Max(Math.Max(HolderInfo[3].X + HolderInfo[3].Width, HolderInfo[4].X + HolderInfo[4].Width), HolderInfo[5].X + HolderInfo[5].Width);
                int up = Math.Min(Math.Min(Math.Min(HolderInfo[6].Y, HolderInfo[7].Y), Math.Min(HolderInfo[8].Y, HolderInfo[9].Y)), Math.Min(HolderInfo[10].Y, HolderInfo[11].Y));
                int down = Math.Max(Math.Max(Math.Min(HolderInfo[6].Height, HolderInfo[7].Height), Math.Max(HolderInfo[8].Height, HolderInfo[9].Height)), Math.Max(HolderInfo[10].Height, HolderInfo[11].Height));

                if (rect.X < left + 100) //Left
                {
                    if (rect.Y > HolderInfo[0].Y - 20 && rect.Y + rect.Height < HolderInfo[0].Y + HolderInfo[0].Height + 20) //top
                        return 0;
                    else if (rect.Y > HolderInfo[1].Y - 20 && rect.Y + rect.Height < HolderInfo[1].Y + HolderInfo[1].Height + 20) //middle
                        return 1;
                    else if (rect.Y > HolderInfo[2].Y - 20 && rect.Y + rect.Height < HolderInfo[2].Y + HolderInfo[2].Height + 20) //bottom
                        return 2;                    
                    else return -1;

                }
                else if (rect.X >HolderInfo[12].X-40 && rect.X +rect.Width <HolderInfo[12].X + HolderInfo[12].Width+40 && rect.Y > HolderInfo[12].Y - 40 && rect.Y + rect.Height < HolderInfo[12].Y + HolderInfo[12].Height + 40)
                    return 12;
                else if (rect.X +rect.Width > Right -100) //Right
                {
                    if (rect.Y > HolderInfo[3].Y - 20 && rect.Y + rect.Height < HolderInfo[3].Y + HolderInfo[3].Height + 20) //top
                        return 3;
                    else if (rect.Y > HolderInfo[4].Y - 20 && rect.Y + rect.Height < HolderInfo[4].Y + HolderInfo[4].Height + 20) //middle
                        return 4;
                    else if (rect.Y > HolderInfo[5].Y - 20 && rect.Y + rect.Height < HolderInfo[5].Y + HolderInfo[5].Height + 20) //bottom
                        return 5;
                    else return -1;
                }
                else if (rect.X > HolderInfo[13].X - 40 && rect.X + rect.Width < HolderInfo[13].X + HolderInfo[13].Width + 40 && rect.Y > HolderInfo[13].Y - 20 && rect.Y + rect.Height < HolderInfo[13].Y + HolderInfo[13].Height + 20)
                    return 13;                
                else if (rect.Y > up - 50 && rect.Y + rect.Height < up + down + 50) //Middle
                {
                    if (rect.X > HolderInfo[6].X - 50 && rect.X + rect.Width < HolderInfo[6].X + HolderInfo[6].Width + 50) return 6;
                    else if (rect.X > HolderInfo[7].X - 50 && rect.X + rect.Width < HolderInfo[7].X + HolderInfo[7].Width + 50) return 7;
                    else if (rect.X > HolderInfo[8].X - 50 && rect.X + rect.Width < HolderInfo[8].X + HolderInfo[8].Width + 50) return 8;
                    else if (rect.X > HolderInfo[9].X - 50 && rect.X + rect.Width < HolderInfo[9].X + HolderInfo[9].Width + 50) return 9;
                    else if (rect.X > HolderInfo[10].X - 50 && rect.X + rect.Width < HolderInfo[10].X + HolderInfo[10].Width + 50) return 10;
                    else if (rect.X > HolderInfo[11].X - 50 && rect.X + rect.Width < HolderInfo[11].X + HolderInfo[11].Width + 50) return 11;
                }                
            }

            return -1;
        }                                    //PCB Holder 위치정보를 숫자로 반환
        public void LoadInfo()
        {
            string[] array;     //레퍼런스를 만드는데 사용된 PCB갯수
            if (File.Exists("Ref\\Contour.txt"))
            {
                StreamReader sr = new StreamReader(new FileStream("Ref\\Contour.txt", FileMode.Open));
                ContourInfo = new PCBInfo();
                PCBtotla = int.Parse(sr.ReadLine());
                array = sr.ReadLine().Split(' ');
                ContourInfo.X = int.Parse(array[0]);
                ContourInfo.Y = int.Parse(array[1]);
                ContourInfo.Width = int.Parse(array[2]);
                ContourInfo.Height = int.Parse(array[3]);
                ContourInfo.Center.X = int.Parse(array[4]);
                ContourInfo.Center.Y = int.Parse(array[5]);
                ContourInfo.Area = int.Parse(array[6]);
                ContourInfo.Length = int.Parse(array[7]);
                sr.Close();
            }
            else PCBtotla = -1;

            if (File.Exists("Ref\\ContourAngle.txt"))
            {
                StreamReader sr = new StreamReader(new FileStream("Ref\\ContourAngle.txt", FileMode.Open));                
                PCBtotla2 = int.Parse(sr.ReadLine());
                ContourInfo2 = new PCBtestInfo[PCBtotla2];
                for (int i = 0; i < PCBtotla2; i++)
                {
                    array = sr.ReadLine().Split(' ');
                    ContourInfo2[i].X = int.Parse(array[0]);
                    ContourInfo2[i].Y = int.Parse(array[1]);
                    ContourInfo2[i].Degree = double.Parse(array[2]);
                }                
                sr.Close();
            }
            else PCBtotla2 = -1;


            if (File.Exists("Ref\\Holder.txt"))
            {
                StreamReader sr = new StreamReader(new FileStream("Ref\\Holder.txt", FileMode.Open));
                HolderCount = int.Parse(sr.ReadLine());
                HolderInfo = new PCBInfo[HolderCount];
                //12개의 홀더 영역 정보 저장
                for (int i = 0; i < HolderCount; i++)
                {
                    array = sr.ReadLine().Split(' ');
                    HolderInfo[i].X = int.Parse(array[0]);
                    HolderInfo[i].Y = int.Parse(array[1]);
                    HolderInfo[i].Width = int.Parse(array[2]);
                    HolderInfo[i].Height = int.Parse(array[3]);
                    HolderInfo[i].Center.X = int.Parse(array[4]);
                    HolderInfo[i].Center.Y = int.Parse(array[5]);
                    HolderInfo[i].Area = int.Parse(array[6]);
                    HolderInfo[i].Length = int.Parse(array[7]);
                }

                sr.Close();
            }
            else HolderCount = -1;

            if (File.Exists("Ref\\Holder.txt"))
            {
                HolderInfo2 = new PCBtestInfo[HolderCount][];
                for (int i = 0; i < HolderCount; i++)
                {
                    StreamReader sr = new StreamReader(new FileStream("Ref\\HolderInfoAngle"+i.ToString() + ".txt", FileMode.Open));
                    HolderCount2 = int.Parse(sr.ReadLine());
                    HolderInfo2[i] = new PCBtestInfo[HolderCount2];
                    //12개의 홀더 영역 정보 저장
                    for (int j = 0; j < HolderCount2; j++)
                    {
                        array = sr.ReadLine().Split(' ');
                        HolderInfo2[i][j].X = int.Parse(array[0]);
                        HolderInfo2[i][j].Y = int.Parse(array[1]);
                        HolderInfo2[i][j].Degree = double.Parse(array[2]);
                    }
                    sr.Close();
                }                
            }
            else HolderCount = -1;



            if (File.Exists("Ref\\Circle.txt"))
            {
                StreamReader sr = new StreamReader(new FileStream("Ref\\Circle.txt", FileMode.Open));
                CircleCount = int.Parse(sr.ReadLine());
                CircleInfo = new PCBInfo[CircleCount + 1];
                //6개의 원 영역 정보 저장
                for (int i = 0; i < CircleCount; i++)
                {
                    array = sr.ReadLine().Split(' ');
                    CircleInfo[i].X = int.Parse(array[0]);
                    CircleInfo[i].Y = int.Parse(array[1]);
                    CircleInfo[i].Width = int.Parse(array[2]);
                    CircleInfo[i].Height = int.Parse(array[3]);
                    CircleInfo[i].Area = int.Parse(array[4]);
                    CircleInfo[i].Length = int.Parse(array[5]);
                }
                //평균 값 저장
                array = sr.ReadLine().Split(' ');
                CircleInfo[CircleCount].X = 0;
                CircleInfo[CircleCount].Y = 0;
                CircleInfo[CircleCount].Width = int.Parse(array[0]);
                CircleInfo[CircleCount].Height = int.Parse(array[1]);
                CircleInfo[CircleCount].Area = int.Parse(array[2]);
                CircleInfo[CircleCount].Length = int.Parse(array[3]);
                sr.Close();
            }
            else CircleCount = -1;

            if (PCBtotla == -1 || HolderCount == -1 || CircleCount == -1)
            {
                MessageBox.Show("검사 기준 정보가 없습니다.");
            }
            else
            {
                if (File.Exists("Ref\\Contour.bmp"))
                {
                    dst = new IplImage[3];
                    dst[0] = Cv.LoadImage("Ref\\Contour.bmp", LoadMode.GrayScale);
                    //dst[1] = Cv.LoadImage("Ref\\Holder.bmp", LoadMode.GrayScale);
                    //dst[2] = Cv.LoadImage("Ref\\CIrcle.bmp", LoadMode.GrayScale);
                }
                else MessageBox.Show("검사 기준 정보가 없습니다.");
            }
        }                                                               //PCB검사용 정보 읽기  
        public void VS(PCBtestInfo[] Ref, PCBtestInfo[] dst,int size,int x,int y)
        {            
            for (int i = 0; i < dst.Length; i++)
            {
                for (int j = 0; j < Ref.Length; j++)
                {
                    if (Math.Abs(dst[i].X+x - Ref[j].X) < size && Math.Abs(dst[i].Y+y - Ref[j].Y) < size)
                    {
                        dst[i].Degree -= Ref[j].Degree;
                        j = Ref.Length;
                    }
                }
            }
        }            //Ref정보와 차이 비교
        public bool FindRadian(PCBtestInfo[] dst,double radian)
        {
            double degree = 0;
            for (int i = 0; i < dst.Length; i++)
            {
                degree += dst[i].Degree;
            }
            if (Math.Abs(degree - radian) > 30.0) return true;
            return false;
        }  //Holder7~10 영역의 각도 합이 360근처일 경우 패스
        public void Print(IplImage src, PCBtestInfo[] info,int size)
        {
            Contours CC = new Contours(info.Length);
            CC.path = size;
            for (int i = 0; i < info.Length; i++)
                if (info[i].Degree > 15.0) CC.Add(new CvPoint(info[i].X, info[i].Y));

            CC.Sort();
            for (int i = 0; i < CC.num; i++)
            {
                if (CC.contour[i].count > 1)
                {
                    Cv.Rectangle(src, new CvRect(CC.contour[i].senter.X - 30, CC.contour[i].senter.Y - 30, 60, 60), new CvScalar(0, 255, 0));
                }
            }
            
            /*
            for (int i = 0; i < info.Length; i++)
            {
                if (info[i].Degree > 10.0)
                {
                    Cv.PutText(src, info[i].Degree.ToString("0."), new CvPoint(info[i].X, info[i].Y - 20), font, new CvScalar(255, 0, 255));
                    Cv.Circle(src, new CvPoint(info[i].X, info[i].Y), 2, new CvScalar(255, 0, 255));
                }
            }*/
        }           //조건 비교후 차이가 나는 부분 출력
        //////////////////////////////////////////검사를 위해 사용하는 함수//////////////////////////////////////////


        /////////////////////////////////////////////////버튼부분////////////////////////////////////////////////
        private void PCBTest(object sender, EventArgs e)
        {
            if (PCBtotla == -1 || HolderCount == -1 || CircleCount == -1)
            {
                MessageBox.Show("검사 기준 정보가 없습니다.");
                return;
            }

            for (int i = 0; i < count; i++)
            {
                ///////////////////각종 초기화 부분/////////////////
                sw.Start();
                CvMemStorage stor;                          //객체가 저장되는 실제 메모리
                CvSeq<CvPoint> contours;                    //객체 정보를 담는 변수
                CvRect rect, pcvrect;                       //객체들의 사각형정보 기본
                CvBox2D rect2, pcvrect2;                    //객체들의 적응 사각형정보 기본
                pcvrect2 = new CvBox2D();
                CvPoint[] pp = new CvPoint[1];
                CvPoint[] pcbrect = new CvPoint[4];
                pcvrect.X = 0;
                pcvrect.Y = 0;
                pcvrect.Width = 0;
                pcvrect.Height = 0;                
                Cv.InitFont(out font, FontFace.HersheyComplex, 1, 1);
                double Area;
                ///////////////////각종 초기화 부분/////////////////


                ///////////////////////////////////////////이미지 Alien 맞추기////////////////////////////////////////////////////            
                Cv.CvtColor(src[i], gray, ColorConversion.BgrToGray);   //gray화
                Cv.Threshold(gray, PCB, 0, 255, ThresholdType.Otsu);    //Otus Threshold적용   
                PCB.Not(PCB);
                stor = Cv.CreateMemStorage();
                Cv.FindContours(PCB, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));     //외각 추출
                PCB.Zero();                
                while (contours != null)
                {
                    rect = Cv.BoundingRect(contours);
                    if (rect.Width > 1000 && rect.Height > 600)
                    {
                        pcvrect = rect;
                        pcvrect2 = Cv.MinAreaRect2(contours);
                        Cv.DrawContours(PCB, contours, new CvScalar(255), new CvScalar(255), -1, -1);
                    }
                    contours = contours.HNext;
                }
                ///////////////발견된 PCB로 추측되는것이 없으면 종료///////////////
                if (pcvrect2.Size.Width < 1)
                {
                    MessageBox.Show("pcb 없음");
                    return;
                }
                ///////////////발견된 PCB로 추측되는것이 없으면 종료///////////////

                //쓸모없는 영역 제거//
                PCB.Not(PCB);
                PCB = smalls(PCB, 400);
                PCB.Not(PCB);
                //쓸모없는 영역 제거//

                //PCB이외의 부분 검은색으로 만들기//
                unsafe
                {
                    for (int h = 0; h < gray.Height; h++)
                    {
                        for (int w = 0; w < gray.Width; w++)
                        {
                            if (PCB.ImageDataPtr[h * PCB.WidthStep + w]== 0)
                            {
                                src[i].ImageDataPtr[h * src[i].WidthStep + w * 3]=0;
                                src[i].ImageDataPtr[h * src[i].WidthStep + w * 3+1] = 0;
                                src[i].ImageDataPtr[h * src[i].WidthStep + w * 3+2] = 0;
                            }
                        }
                    }
                }
                //PCB이외의 부분 검은색으로 만들기//

                //////////////실제 Alien부분///////////////
                pcbrect = Findstraight(pcvrect, pcvrect2); //pcb의 좌표 영역 설정 (틀어진 부분에 대한 보정작업을 위한 좌표설정)
                int abase = pcbrect[1].X - pcbrect[0].X;
                int aheight = pcbrect[1].Y - pcbrect[0].Y;
                double degree;
                if (aheight != 0) degree = Math.Atan((double)abase / (double)aheight) * 180.0 / 3.141592;
                else degree = 0;                
                if (degree >= 50) degree = 90.0 - degree;
                else if (degree <= -50) degree = -degree-90;
                CvPoint2D32f center = new CvPoint2D32f(pcvrect2.Center.X, pcvrect2.Center.Y);
                CvMat Rotate = Cv.CreateMat(2,3,MatrixType.F32C1);
                Cv._2DRotationMatrix(center, degree, 1, out Rotate);
                Cv.WarpAffine(src[i], src[i], Rotate, Interpolation.Linear);                //각도 보정
                //ContourInfo.X + ContourInfo.Width / 2, ContourInfo.Y + ContourInfo.Height / 2,
                src[i] = Transrate(src[i], (int)pcvrect2.Center.X, (int)pcvrect2.Center.Y); // ); //위치 보정
                /////////////실제 Alien부분///////////////

                ///////////////////////////////////////////이미지 Alien 맞추기////////////////////////////////////////////////////
                Cv.CvtColor(src[i], gray, ColorConversion.BgrToGray);                
                //Alien작업중에 이미 PCB이외의 영역은 0으로 처리가 되었으므로 1보다 큰값만 남겨준다.                
                Cv.Threshold(gray, PCB, 1, 255, ThresholdType.Binary);
                stor = Cv.CreateMemStorage();
                Cv.FindContours(PCB, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));     //외각 추출
                PCB.Zero();
                PCBtestInfo[] Info;
                while (contours != null)
                {
                    rect = Cv.BoundingRect(contours);
                    if (rect.Width > 1000 && rect.Height > 600)
                    {
                        pcvrect = rect;
                        pcvrect2 = Cv.MinAreaRect2(contours);
                        Cv.DrawContours(PCB, contours, new CvScalar(255), new CvScalar(255), -1, -1);        
                        //이미지에 글자출력
                        string text = "w" + Math.Max(pcvrect2.Size.Width, pcvrect2.Size.Height).ToString("0.") + " h" + Math.Min(pcvrect2.Size.Width, pcvrect2.Size.Height).ToString("0.");
                        Cv.PutText(src[i], text, new CvPoint(pcvrect.X, pcvrect.Y - 40), font, new CvScalar(0, 0, 255));
                        //좌표정보를 추출하여 Ref정보와 비교 연산//
                        Info = Inspection(contours.ToArray(), 30, 0.5);
                        VS(ContourInfo2, Info, 35, ContourInfo.Center.X - (int)pcvrect2.Center.X, ContourInfo.Center.Y - (int)pcvrect2.Center.Y);
                        Print(src[i], Info,50);
                        //좌표정보를 추출하여 Ref정보와 비교 연산//
                    }
                    contours = contours.HNext;
                }
                if (checkBox2.Checked) PCB.SaveImage("PCBcontours.bmp");
                dst[1] = Cv.CreateImage(Cv.GetSize(dst[0]), dst[0].Depth, 1);
                dst[2] = Cv.CreateImage(Cv.GetSize(dst[0]), dst[0].Depth, 1);
                PCB.Sub(dst[0], dst[1]);                
                dst[0].Sub(PCB, dst[2]);
                dst[2].Add(dst[1], PCB);
                PCB.Erode(PCB, null, 10);
                PCB.Dilate (PCB, null, 5);
                PCB.SaveImage("PCB.bmp");
                stor = Cv.CreateMemStorage();
                Cv.FindContours(PCB, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));     //외각 추출
                PCB.Zero();
                while (contours != null)
                {
                    rect = Cv.BoundingRect(contours);
                    if (rect.Width > 5 && rect.Height > 5)
                    {
                        Cv.Rectangle(src[i], rect, new CvScalar(0, 0, 255));
                    }
                    contours = contours.HNext;
                }
                pcbrect = Findstraight(pcvrect, pcvrect2);

                //설정 좌표영역 이미지에 출력
                string tet = "1 " + pcbrect[0].X.ToString() + " " + pcbrect[0].Y.ToString();
                Cv.PutText(src[i], tet, new CvPoint(pcbrect[0].X, pcbrect[0].Y), font, new CvScalar(0, 0, 255));
                tet = "2 " + pcbrect[1].X.ToString() + " " + pcbrect[1].Y.ToString();
                Cv.PutText(src[i], tet, new CvPoint(pcbrect[1].X, pcbrect[1].Y), font, new CvScalar(0, 0, 255));
                tet = "3 " + pcbrect[2].X.ToString() + " " + pcbrect[2].Y.ToString();
                Cv.PutText(src[i], tet, new CvPoint(pcbrect[2].X, pcbrect[2].Y), font, new CvScalar(0, 0, 255));
                tet = "4 " + pcbrect[3].X.ToString() + " " + pcbrect[3].Y.ToString();
                Cv.PutText(src[i], tet, new CvPoint(pcbrect[3].X, pcbrect[3].Y), font, new CvScalar(0, 0, 255));



                //PCB 내부 패턴검출
                //이미지 밝기값에 따른 임계값을 구하여 Threshold설정
                Cv.Threshold(gray, Holder, getColor(gray) * 1.8, 255, ThresholdType.Binary);
                //PCB외각의 사각 좌표를 벗어난 부분은 제거
                Cv.DrawRect(Holder, new CvRect(0, 0, gray.Width, pcvrect.Y + 300), new CvScalar(0), -1);
                Cv.DrawRect(Holder, new CvRect(0, pcvrect.Y + pcvrect.Height, gray.Width, pcvrect.Height), new CvScalar(0), -1);
                Cv.DrawRect(Holder, new CvRect(0, pcvrect.Y, pcvrect.X, pcvrect.Height), new CvScalar(0), -1);
                Cv.DrawRect(Holder, new CvRect(pcvrect.X + pcvrect.Width, pcvrect.Y, gray.Width - (pcvrect.X + pcvrect.Width), pcvrect.Height), new CvScalar(0), -1);
                //1번과 4번부분에서 연결될때와 안될때가 있으므로 일부분을 지워 무조건 떨어져있게 만듬. 대신 그 부분에 대한 불량은 잡지 못함.
                Cv.DrawRect(Holder, new CvRect(580, 975, 90, 110), new CvScalar(0), -1);
                Cv.DrawRect(Holder, new CvRect(1913, 975, 90, 110), new CvScalar(0), -1);

                Holder = smalls(Holder, 30); //크기 30보다 작은 영역은 삭제                
                Holder.Copy(gray);      //원 추출을 위해 따로 저장
                stor = Cv.CreateMemStorage();
                Cv.FindContours(Holder, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));     //외각 추출
                Holder.Zero();
                Feature_gray.Zero();
                int HoleCount;
                int[] Hole = new int[14];
                for (int h = 0; h < 14; h++) Hole[h] = 1;
                while (contours != null)
                {
                    rect = Cv.BoundingRect(contours);

                    if (rect.X > pcvrect.X && rect.Y > pcvrect.Y + 100 && rect.X + rect.Width < pcvrect.X + pcvrect.Width && rect.Y + rect.Height < pcvrect.Y + pcvrect.Height)
                    {
                        if (rect.Width > 50 && rect.Height > 50)
                        {
                            rect2 = Cv.MinAreaRect2(contours);
                            if (checkBox2.Checked) Cv.DrawContours(Holder, contours, new CvScalar(255), new CvScalar(255), -1, -1);                            
                            Area = Math.Abs(Cv.ContourArea(contours));

                            //좌표정보를 추출하여 Ref정보와 비교 연산//
                            HoleCount = getPattern(pcbrect, rect);
                            if (HoleCount <= 11 && HoleCount >=0)
                            {
                                if (Math.Abs(HolderInfo[HoleCount].Area / Area) > 1.1 || Math.Abs(HolderInfo[HoleCount].Area / Area) < 0.9)
                                {
                                    Cv.Rectangle(src[i], rect, new CvScalar(0, 0, 255));
                                }
                                Hole[HoleCount] = 0;
                                if (Area < 10000) Info = Inspection(contours.ToArray(), 20, 0.35);
                                else Info = Inspection(contours.ToArray(), 30, 0.35);

                                if (HoleCount >= 7 && HoleCount <= 10)
                                {
                                    if (FindRadian(Info, 360))
                                    {
                                        VS(HolderInfo2[HoleCount], Info, 25, HolderInfo[HoleCount].Center.X - (int)rect2.Center.X, HolderInfo[HoleCount].Center.Y - (int)rect2.Center.Y);
                                    }
                                    else Info = new PCBtestInfo[1];
                                }
                                else if (HoleCount >= 0) VS(HolderInfo2[HoleCount], Info, 25, HolderInfo[HoleCount].Center.X - (int)rect2.Center.X, HolderInfo[HoleCount].Center.Y - (int)rect2.Center.Y);
                                Print(src[i], Info,30);
                            }
                            else if (HoleCount > 11)
                            {
                                Hole[HoleCount] = 0;
                                if (Math.Abs(Area - HolderInfo[HoleCount].Area) > 1500) Cv.Rectangle(src[i], rect, new CvScalar(0, 0, 255));
                            }
                            //좌표정보를 추출하여 Ref정보와 비교 연산//
                        }
                    }
                    contours = contours.HNext;
                }
                if (checkBox2.Checked) Holder.SaveImage("PCBHolder.bmp");

                //Holder가 아예 없을경우 불량표시//
                for (int h = 0; h < 14; h++)
                    if (Hole[h] == 1) Cv.Rectangle(src[i], new CvRect(HolderInfo[h].X, HolderInfo[h].Y, HolderInfo[h].Width, HolderInfo[h].Height), new CvScalar(255, 0, 0));
                //Holder가 아예 없을경우 불량표시//


                //MessageBox.Show("circle");
                //////패턴 내부 원////// 원은 넓이와 내부 이물만 검사
                int[] circle = new int[6];
                for (int h = 0; h < 6; h++) circle[h] = 1;
                Cv.FloodFill(gray, new CvPoint(10 , 10), new CvScalar(255));
                gray.Not(gray);
                gray = smalls(gray, 20);
                if (checkBox2.Checked) gray.SaveImage("PCBCircle.bmp");
                stor = Cv.CreateMemStorage();
                Cv.FindContours(gray, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));     //외각 추출
                while (contours != null)
                {
                    rect = Cv.BoundingRect(contours);
                    //PCB외각 영역 내부라면
                    if (rect.X > pcvrect.X && rect.Y > pcvrect.Y && rect.X + rect.Width < pcvrect.X + pcvrect.Width && rect.Y + rect.Height < pcvrect.Y + pcvrect.Height)
                    {
                        //영역이 10,10보다 크다면
                        if (rect.Width > 10 && rect.Height > 10)
                        {
                            rect2 = Cv.MinAreaRect2(contours);    
                            Area = Math.Abs(Cv.ContourArea(contours));
                            HoleCount= getPattern(pcbrect, rect);
                            if (HoleCount > 5 || HoleCount == -1) { }
                            else
                            {
                                circle[HoleCount] = 0;
                                if (Math.Abs(Area / CircleInfo[CircleCount].Area) > 1.2 || Math.Abs(CircleInfo[CircleCount].Area / Area) < 0.8)
                                {
                                    if (rect.Width / rect.Height > 1.1 || rect.Width / rect.Height < 0.9)
                                    {
                                        MessageBox.Show(CircleInfo[CircleCount].Area.ToString("0.") + " " + Area.ToString("0."));
                                        Cv.Rectangle(src[i], rect, new CvScalar(0, 0, 255));
                                    }
                                }
                            }
                        }
                    }
                    contours = contours.HNext;
                }
                for (int h = 0; h < 6; h++)
                    if (circle[h] == 1) Cv.Rectangle(src[i], new CvRect(CircleInfo[h].X, CircleInfo[h].Y, CircleInfo[h].Width, CircleInfo[h].Height), new CvScalar(255, 0, 0));
                //////패턴 내부 원//////

                //IplImage to Bmp
                unsafe
                {
                    Bitmap bitmap = new Bitmap(src[i].Width, src[i].Height, src[i].WidthStep, System.Drawing.Imaging.PixelFormat.Format24bppRgb, new IntPtr(src[i].ImageDataPtr));
                    pictureBox1.Image = bitmap;
                    
                }
                sw.Stop();
                MessageBox.Show(sw.ElapsedMilliseconds.ToString() + "ms");
                sw.Reset();
            }
        }                                      //실제 검사 부분
        private void Make_PCB_Ref(object sender, EventArgs e)
        {            
            openFileDialog2.Filter = "All |*.*|JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif";
            openFileDialog2.FilterIndex = 1;
            openFileDialog2.Multiselect = true;

            if (openFileDialog2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                sw.Start();
                asb = openFileDialog2.FileNames;
                asb2 = openFileDialog2.SafeFileNames;
                count = openFileDialog2.SafeFileNames.Length;
                src = new IplImage[count];
                dst = new IplImage[3];
                src[0] = Cv.LoadImage(asb[0], LoadMode.GrayScale);                
                gray = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                dst[0] = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                dst[1] = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                dst[2] = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                dst[0].Zero();
                dst[1].Zero();
                dst[2].Zero();
                IplImage PCB = Cv.CreateImage(Cv.GetSize(src[0]), src[0].Depth, 1);
                CvMemStorage stor;                          //객체가 저장되는 실제 메모리
                CvSeq<CvPoint> contours;                    //객체 정보를 담는 변수
                CvRect rect, pcvrect;                                //객체들의 사각형정보 기본
                CvBox2D pcvrect2,rect2;                              //객체들의 적응 사각형정보 기본
                pcvrect2 = new CvBox2D();
                CvPoint[] pp = new CvPoint[1];
                CvPoint[] pcbrect = new CvPoint[4];
                pcvrect.X = 0;
                pcvrect.Y = 0;
                pcvrect.Width = 0;
                pcvrect.Height = 0;

                for (int i = 0; i < count; i++)
                {
                    src[i] = Cv.LoadImage(asb[i],LoadMode.GrayScale);
                    src[i].Smooth(src[i],SmoothType.Median,3);
                    src[i].Copy(gray);
                    pcvrect.X = 0;
                    pcvrect.Y = 0;
                    pcvrect.Width = 0;
                    pcvrect.Height = 0;
                    //PCB 외각 검출
                    Cv.Threshold(gray, PCB, 0, 255, ThresholdType.Otsu);
                    PCB.Not(PCB);
                    stor = Cv.CreateMemStorage();
                    if (Cv.FindContours(PCB, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0)) > 0)
                    {
                        PCB.Zero();
                        while (contours != null)
                        {
                            rect = Cv.BoundingRect(contours);
                            if (rect.Width > 1000 && rect.Height > 600)
                            {
                                pcvrect = rect;
                                pcvrect2 = Cv.MinAreaRect2(contours);
                                Cv.DrawContours(PCB, contours, new CvScalar(255), new CvScalar(255), -1, -1);
                            }
                            contours = contours.HNext;
                        }
                    }
                    else
                    {
                        MessageBox.Show("pcb 없음");
                        continue;
                    }            
        
                    PCB.Not(PCB);
                    PCB = smalls(PCB, 400);
                    PCB.Not(PCB);
                    unsafe
                    {
                        for (int h = 0; h < gray.Height; h++)
                        {
                            for (int w = 0; w < gray.Width; w++)
                            {
                                if (PCB.ImageDataPtr[h * PCB.WidthStep + w] == 0)
                                {
                                    src[i].ImageDataPtr[h * src[i].WidthStep + w * src[i].NChannels] = 0;
                                }
                            }
                        }
                    }

                    pcbrect = Findstraight(pcvrect, pcvrect2);
                    double degree;
                    if (pcbrect[1].Y - pcbrect[0].Y != 0) degree = Math.Atan((double)(pcbrect[1].X - pcbrect[0].X) / (double)(pcbrect[1].Y - pcbrect[0].Y)) * 180.0 / 3.141592;
                    else degree = 0;

                    if (degree >= 50)
                    {
                        degree = 90.0 - degree;
                    }
                    else if (degree <= -50)
                    {
                        degree = -degree - 90;
                    }
                    
                    CvPoint2D32f center = new CvPoint2D32f(pcvrect2.Center.X, pcvrect2.Center.Y);
                    CvMat Rotate = Cv.CreateMat(2, 3, MatrixType.F32C1);
                    Cv._2DRotationMatrix(center, degree, 1, out Rotate);
                    Cv.WarpAffine(src[i], src[i], Rotate, Interpolation.Linear);

                    Cv.Threshold(src[i], PCB, 1, 255, ThresholdType.Binary);
                    //PCB.Not(PCB);
                    stor = Cv.CreateMemStorage();
                    Cv.FindContours(PCB, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));     //외각 추출                    
                    while (contours != null)
                    {
                        rect = Cv.BoundingRect(contours);
                        if (rect.Width > 1000 && rect.Height > 600)
                        {
                            pcvrect = Cv.BoundingRect(contours);
                            pcvrect2 = Cv.MinAreaRect2(contours);
                        }
                        contours = contours.HNext;
                    }
                    src[i] = Transrate(src[i], pcvrect.X + pcvrect.Width / 2, pcvrect.Y + pcvrect.Height/2);
                    src[i].Copy(gray);
                    Cv.Threshold(gray, PCB, 1, 255, ThresholdType.Binary);

                    stor = Cv.CreateMemStorage();
                    Cv.FindContours(PCB, stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));     //외각 추출
                    PCB.Zero();
                    while (contours != null)
                    {
                        rect = Cv.BoundingRect(contours);
                        if (rect.Width > 1000 && rect.Height > 600)
                        {
                            pcvrect = rect;
                            pcvrect2 = Cv.MinAreaRect2(contours);
                            Cv.DrawContours(PCB, contours, new CvScalar(255), new CvScalar(255), -1, -1);
                        }
                        contours = contours.HNext;
                    }
                    pcbrect = Findstraight(pcvrect, pcvrect2);
                    //영역을 찾아 contours에 저장   
                    unsafe
                    {
                        unsafe
                        {
                            for (int h = 0; h < gray.Height; h++)
                            {
                                for (int w = 0; w < gray.Width; w++)
                                {
                                    if (PCB.ImageDataPtr[h * PCB.WidthStep + w] == 255)
                                    {
                                        dst[0].ImageDataPtr[h * dst[0].WidthStep + w] += 1;
                                    }
                                }
                            }
                        }
                    }

                    //PCB 내부 Holder검출                    
                    Cv.Threshold(gray, PCB, getColor(gray) * 1.7, 255, ThresholdType.Binary);
                    Cv.DrawRect(PCB, new CvRect(0, 0, gray.Width, pcvrect.Y + 300), new CvScalar(0), -1);
                    Cv.DrawRect(PCB, new CvRect(0, pcvrect.Y + pcvrect.Height, gray.Width, pcvrect.Height), new CvScalar(0), -1);
                    Cv.DrawRect(PCB, new CvRect(0, pcvrect.Y, pcvrect.X, pcvrect.Height), new CvScalar(0), -1);
                    Cv.DrawRect(PCB, new CvRect(pcvrect.X + pcvrect.Width, pcvrect.Y, gray.Width - (pcvrect.X + pcvrect.Width), pcvrect.Height), new CvScalar(0), -1);
                    Cv.DrawRect(PCB, new CvRect(600, 965, 60, 60), new CvScalar(0), -1);
                    Cv.DrawRect(PCB, new CvRect(1913, 965, 60, 60), new CvScalar(0), -1);

                    PCB = smalls(PCB, 30);
                    unsafe
                    {
                        unsafe
                        {
                            for (int h = 0; h < gray.Height; h++)
                            {
                                for (int w = 0; w < gray.Width; w++)
                                {
                                    if (PCB.ImageDataPtr[h * PCB.WidthStep + w] == 255)
                                    {
                                        dst[1].ImageDataPtr[h * dst[1].WidthStep + w] += 1;
                                    }
                                }
                            }
                        }
                    }                 

                    //Holder 내부 원
                    Cv.FloodFill(PCB, new CvPoint(10, 10), new CvScalar(255));
                    PCB.Not(PCB);
                    PCB = smalls(PCB, 40);
                    unsafe
                    {
                        for (int h = 0; h < gray.Height; h++)
                        {
                            for (int w = 0; w < gray.Width; w++)
                            {
                                if (PCB.ImageDataPtr[h * PCB.WidthStep + w] == 255)
                                {
                                    dst[2].ImageDataPtr[h * dst[2].WidthStep + w] += 1;
                                }
                            }
                        }
                    }   
                }

                dst[2].EqualizeHist(dst[2]);
                dst[0].Threshold(dst[0], count / 2, 255, ThresholdType.Binary);
                dst[1].Threshold(dst[1], count / 2, 255, ThresholdType.Binary);
                dst[2].Threshold(dst[2], 255 * 0.2, 255, ThresholdType.Binary);
                
                src[0] = Cv.CreateImage(Cv.GetSize(gray), gray.Depth, 3);
                src[0].Zero();

                CvFont font;
                Cv.InitFont(out font, FontFace.HersheyComplex, 1, 1);
                string text = " ";
                int j = 0;
                string savePath = @"Ref\\Contour.txt";
                string textvalue = "";

                dst[0].Threshold(dst[0], 0, 255, ThresholdType.Binary);
                stor = Cv.CreateMemStorage();
                int ContourCount = Cv.FindContours(dst[0], stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));
                dst[0].Zero();
                ContourInfo = new PCBInfo();
                ContourInfo2 = new PCBtestInfo[ContourCount];
                textvalue += count.ToString();
                while (contours != null)
                {
                    //Cv.DrawContours(src[0], contours, new CvScalar(255, 255, 255), new CvScalar(255, 255, 255), 1, 1);
                    rect = Cv.BoundingRect(contours);
                    if (rect.Width > 1000/1 && rect.Height > 800/1)
                    {
                        pcvrect = rect;
                        pcvrect2 = Cv.MinAreaRect2(contours);
                        ContourInfo.X = rect.X;
                        ContourInfo.Y = rect.Y;
                        ContourInfo.Width = rect.Width;
                        ContourInfo.Height = rect.Height;
                        ContourInfo.Center.X = (int)pcvrect2.Center.X;
                        ContourInfo.Center.Y = (int)pcvrect2.Center.Y;
                        ContourInfo.Area = Math.Abs(Cv.ContourArea(contours));
                        ContourInfo.Length = Cv.ArcLength(contours);
                        ContourInfo2 = Inspection(contours.ToArray(), 30, 0.5);
                        textvalue += "\r\n" + ContourInfo.X.ToString() + " " + ContourInfo.Y.ToString() + " " + ContourInfo.Width.ToString() + " " + ContourInfo.Height.ToString() + " " + ContourInfo.Center.X.ToString() + " " + ContourInfo.Center.Y.ToString() + " " + ContourInfo.Area.ToString("0.") + " " + ContourInfo.Length.ToString("0.");
                        //Cv.DrawContours(src[0], contours, new CvScalar(255, 255, 255), new CvScalar(255, 255, 255), 1, 1);
                        Cv.DrawContours(dst[0], contours, new CvScalar(255), new CvScalar(255), -1, -1);
                    }
                    contours = contours.HNext;
                }
                System.IO.File.WriteAllText(savePath, textvalue, Encoding.Default);
                savePath = @"Ref\\ContourAngle.txt";
                textvalue = ContourInfo2.Length.ToString();
                for (int i = 0; i < ContourInfo2.Length; i++)
                {
                    text = ContourInfo2[i].Degree.ToString("0.");
                    //Cv.PutText(dst[0], text, new CvPoint(ContourInfo2[i].X, ContourInfo2[i].Y), font, new CvScalar(255));
                    //Cv.Circle(dst[0], new CvPoint(ContourInfo2[i].X, ContourInfo2[i].Y), 2, new CvScalar(123));
                    textvalue += "\r\n" + (ContourInfo2[i].X*1) + " " + (ContourInfo2[i].Y*1) + " " + ((int)ContourInfo2[i].Degree).ToString();
                }
                System.IO.File.WriteAllText(savePath, textvalue, Encoding.Default);
                                
                //resize.Resize(dst[0], Interpolation.Linear);                    
                dst[0].SaveImage("Ref\\Contour.bmp");
                pcbrect = Findstraight(pcvrect, pcvrect2);

                savePath = @"Ref\\Holder.txt";
                textvalue = "";                
                stor = Cv.CreateMemStorage();
                int HolderCount = Cv.FindContours(dst[1], stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));
                dst[1].Zero();
                HolderInfo = new PCBInfo[HolderCount];
                HolderInfo2 = new PCBtestInfo[HolderCount][];
                j = 0;
                int GetHolder;
                while (contours != null)
                {   
                    Cv.DrawContours(src[0], contours, new CvScalar(255, 255, 255), new CvScalar(255, 255, 255), 1, 1);
                    rect = Cv.BoundingRect(contours);
                    if (rect.X > ContourInfo.X && rect.Y > ContourInfo.Y && rect.X + rect.Width < ContourInfo.X + ContourInfo.Width && rect.Y + rect.Height < ContourInfo.Y + ContourInfo.Height)
                    {
                        if (rect.Width > 50 && rect.Height > 50)
                        {
                            rect2 = Cv.MinAreaRect2(contours);
                            GetHolder = HolderFind(rect);                            
                            HolderInfo[GetHolder].X = rect.X;
                            HolderInfo[GetHolder].Y = rect.Y;
                            HolderInfo[GetHolder].Width = rect.Width;
                            HolderInfo[GetHolder].Height = rect.Height;
                            HolderInfo[GetHolder].Center.X = (int)rect2.Center.X;
                            HolderInfo[GetHolder].Center.Y = (int)rect2.Center.Y;
                            HolderInfo[GetHolder].Area = Math.Abs(Cv.ContourArea(contours));
                            HolderInfo[GetHolder].Length = Cv.ArcLength(contours);
                            if(HolderInfo[GetHolder].Area<10000)
                                HolderInfo2[GetHolder] = Inspection(contours.ToArray(), 20, 0.35);
                            else
                                HolderInfo2[GetHolder] = Inspection(contours.ToArray(), 30, 0.35);
                            Cv.DrawContours(dst[1], contours, new CvScalar(255), new CvScalar(255), 1, 1);                             
                            j++;
                        }
                    }                    
                    contours = contours.HNext;
                }
                textvalue += j.ToString();
                for (int i = 0; i < j; i++)
                    textvalue += "\r\n" + HolderInfo[i].X.ToString() + " " + HolderInfo[i].Y.ToString() + " " + HolderInfo[i].Width.ToString() + " " + HolderInfo[i].Height.ToString() + " " + HolderInfo[i].Center.X.ToString() + " " + HolderInfo[i].Center.Y.ToString() + " " + HolderInfo[i].Area.ToString("0.") + " " + HolderInfo[i].Length.ToString("0.");
                                
                System.IO.File.WriteAllText(savePath, textvalue, Encoding.Default);                
                for (int i = 0; i < j; i++)
                {
                    savePath = @"Ref\\HolderInfoAngle" + i.ToString() + ".txt";
                    textvalue = HolderInfo2[i].Length.ToString();
                    for (int k = 0; k < HolderInfo2[i].Length; k++)
                    {
                        text = HolderInfo2[i][k].Degree.ToString("0.");
                        Cv.PutText(dst[1], text, new CvPoint(HolderInfo2[i][k].X, HolderInfo2[i][k].Y), font, new CvScalar(255));
                        Cv.Circle(dst[1], new CvPoint(HolderInfo2[i][k].X, HolderInfo2[i][k].Y), 2, new CvScalar(123));
                        textvalue += "\r\n" + (HolderInfo2[i][k].X) + " " + (HolderInfo2[i][k].Y) + " " + (HolderInfo2[i][k].Degree).ToString("0.");
                    }
                    System.IO.File.WriteAllText(savePath, textvalue, Encoding.Default);
                }
                dst[1].SaveImage("Ref\\Holder.bmp");



                savePath = @"Ref\\Circle.txt";
                textvalue = "";
                stor = Cv.CreateMemStorage();
                int CircleCount = Cv.FindContours(dst[2], stor, out contours, CvContour.SizeOf, ContourRetrieval.FloodFill, ContourChain.ApproxNone, new CvPoint(0, 0));
                dst[2].Zero();
                CircleInfo = new PCBInfo[CircleCount];
                j = 0;
                while (contours != null)
                {
                    rect = Cv.BoundingRect(contours);
                    if (rect.X > ContourInfo.X && rect.Y > ContourInfo.Y && rect.X + rect.Width < ContourInfo.X + ContourInfo.Width && rect.Y + rect.Height < ContourInfo.Y + ContourInfo.Height)
                    {
                        if (rect.Width > 10 && rect.Height > 10)
                        {
                            GetHolder = HolderFind(rect);
                            if (GetHolder>=0 && GetHolder <6)
                            {
                                rect2 = Cv.MinAreaRect2(contours);
                                Cv.DrawContours(src[0], contours, new CvScalar(255, 255, 255), new CvScalar(255, 255, 255), 1, 1);
                                Cv.DrawContours(dst[2], contours, new CvScalar(255), new CvScalar(255), 1, 1);
                                CircleInfo[GetHolder].X = rect.X;
                                CircleInfo[GetHolder].Y = rect.Y;
                                CircleInfo[GetHolder].Height = rect.Height;
                                CircleInfo[GetHolder].Width = rect.Width;
                                CircleInfo[GetHolder].Center.X = (int)rect2.Center.X;
                                CircleInfo[GetHolder].Center.Y = (int)rect2.Center.Y;
                                CircleInfo[GetHolder].Area = Math.Abs(Cv.ContourArea(contours));
                                CircleInfo[GetHolder].Length = Cv.ArcLength(contours);                    
                                j++;
                            }                           
                        }
                    }                    
                    contours = contours.HNext;
                }
                dst[2].SaveImage("Ref\\Circle.bmp");

                textvalue += j.ToString();
                for(int i=0;i<j;i++)
                    textvalue += "\r\n" + CircleInfo[i].X.ToString() + " " + CircleInfo[i].Y.ToString() + " " + CircleInfo[i].Width.ToString("0.") + " " + CircleInfo[i].Height.ToString("0.") + " " + CircleInfo[i].Center.X.ToString("0.") + " " + CircleInfo[i].Center.Y.ToString("0.") + " " + CircleInfo[i].Area.ToString("0.") + " " + CircleInfo[i].Length.ToString("0.");

                for (int i = 1; i < CircleCount; i++)
                {
                    CircleInfo[0].Width += CircleInfo[i].Width;
                    CircleInfo[0].Height += CircleInfo[i].Height;                    
                    CircleInfo[0].Area += CircleInfo[i].Area;
                    CircleInfo[0].Length += CircleInfo[i].Length;
                }
                CircleInfo[0].Width /= j;
                CircleInfo[0].Height /= j;
                CircleInfo[0].Area /= (double)j;
                CircleInfo[0].Length /= (double)j;
                textvalue += "\r\n" + CircleInfo[0].Width.ToString() + " " + CircleInfo[0].Height.ToString() + " " + CircleInfo[0].Area.ToString("0.") + " " + CircleInfo[0].Length.ToString("0.");
                System.IO.File.WriteAllText(savePath, textvalue, Encoding.Default);

                sw.Stop();
                MessageBox.Show(sw.ElapsedMilliseconds.ToString() + "ms");
                sw.Reset();
                unsafe
                {
                    Bitmap bitmap = new Bitmap(src[0].Width, src[0].Height, src[0].WidthStep, System.Drawing.Imaging.PixelFormat.Format24bppRgb, new IntPtr(src[0].ImageDataPtr));
                    pictureBox1.Image = bitmap;
                }
                PCBtotla = HolderCount = CircleCount = 1;
            }
        }                                 //Ref만드는 부분
        private void PCBSetting(object sender, EventArgs e)
        {
            Settingcs set = new Settingcs();
            set.ShowDialog();
        }                
        private void Load_Info(object sender, EventArgs e)
        {
            LoadInfo();
        }                             //Ref정보 불러오는 부분
        /////////////////////////////////////////////////버튼부분////////////////////////////////////////////////        
    }
}


