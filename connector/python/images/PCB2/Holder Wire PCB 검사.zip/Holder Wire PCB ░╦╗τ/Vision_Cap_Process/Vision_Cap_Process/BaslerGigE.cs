﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PylonC.NET;
using System.Collections;
using System.Diagnostics;
using System.Threading;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace BaslerCS
{
    public class BaslerGigE
    {
        private PYLON_DEVICE_HANDLE device_handle;

        public BaslerGigE()
        {
        }

        ~BaslerGigE()
        {
        }

        /*********************************************************************************/
        /* for Device                                                                    */
        public bool DevOpen(string IpAddress)
        {
            int index = -1;

            if (device_list.Count > 0)
            {
                for (int i = 0; i < device_list.Count; i++)
                {
                    if (device_list[i].GetPropertyByName("IpAddress") != null)
                    {
                        index = i;
                        break;
                    }
                }
            }

            return DevOpen(index);
        }

        public bool DevOpen(int index)
        {
            bool res = false;

            if (device_list.Count > index)
            {
                PYLON_DEVICE_HANDLE device = Pylon.CreateDeviceByIndex((uint)index);
                res = DevOpen(device);
            }

            return res;
        }

        private bool DevOpen(PYLON_DEVICE_HANDLE device)
        {
            bool res = false;

            if (!DevIsOpen())
            {
                try
                {
                    device_handle = device;
                    Pylon.DeviceOpen(device_handle, Pylon.cPylonAccessModeControl | Pylon.cPylonAccessModeStream);
                    res = DevIsOpen();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }
            }

            return res;
        }

        private bool DevIsOpen()
        {
            bool res = false;

            if (device_handle != null && device_handle.IsValid)
            {
                try
                {
                    res = Pylon.DeviceIsOpen(device_handle);
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }
            }

            return res;
        }

        public void DevClose()
        {
            if (DevIsOpen())
            {
                try
                {
                    Pylon.DeviceClose(device_handle);
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }

                try
                {
                    Pylon.DestroyDevice(device_handle);
                    device_handle.SetInvalid();
                    device_handle = null;
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }
            }
        }

        protected PYLON_STREAMGRABBER_HANDLE DevGetStreamGrabberHandle()
        {
            PYLON_STREAMGRABBER_HANDLE res = null;

            if (DevIsOpen())
            {
                try
                {
                    res = Pylon.DeviceGetStreamGrabber(device_handle, 0);
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }
            }

            return res;
        }
        /* for Device                                                                    */
        /*********************************************************************************/


        /*********************************************************************************/
        /* for StreamGrabber                                                             */
        private const uint image_buffer_count = 3;

        private PYLON_STREAMGRABBER_HANDLE stream_grabber_handle;
        private PYLON_WAITOBJECT_HANDLE wait_object_handle;
        private Object lock_object = new Object();
        protected Dictionary<PYLON_STREAMBUFFER_HANDLE, PylonBuffer<Byte>> image_buffers = new Dictionary<PYLON_STREAMBUFFER_HANDLE, PylonBuffer<Byte>>();

        private Thread grab_thread;
        private bool grab_thread_continue = false;

        public new bool IsOpen()
        {
            bool res = false;

            if (stream_grabber_handle != null && stream_grabber_handle.IsValid)
            {
                try
                {
                    res = Pylon.StreamGrabberIsOpen(stream_grabber_handle);
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }
            }

            return res;
        }

        int index;

        public bool OpenByIndex(uint arg_index)
        {
            bool res = false;

            index = (int)arg_index;

            if (DevOpen((int)arg_index))
            {
                res = Open(DevGetStreamGrabberHandle());
            }

            return res;
        }

        private bool Open(PYLON_STREAMGRABBER_HANDLE arg_stream_grabber)
        {
            bool res = false;

            stream_grabber_handle = arg_stream_grabber;

            if (!IsOpen())
            {
                try
                {
                    Pylon.StreamGrabberOpen(stream_grabber_handle);
                    wait_object_handle = Pylon.StreamGrabberGetWaitObject(stream_grabber_handle);
                    res = IsOpen();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }
            }

            if (res)
            {
                Pylon.DeviceSetIntegerFeature(device_handle, "Width", 2584);
                Pylon.DeviceSetIntegerFeature(device_handle, "Height", 1942);

                Pylon.DeviceSetFloatFeature(device_handle, "ExposureTimeAbs", 8000.0f);
            }

            return res;
        }

        public bool Grab()
        {
            bool res = false;

            if (IsOpen())
            {
                try
                {
                    SetupGrab();

                    Pylon.DeviceExecuteCommandFeature(device_handle, "AcquisitionStart");

                    grab_thread = new Thread(GrabThreadFunction);
                    grab_thread.Start();
                }
                catch (Exception ex)
                {
                    CleanupGrab();
                    Trace.WriteLine(ex.Message);
                }
            }
            return res;
        }

        private void SetupGrab()
        {
            lock (lock_object)
            {
            }

            Pylon.DeviceFeatureFromString(device_handle, "AcquisitionMode", "Continuous");

            foreach (KeyValuePair<PYLON_STREAMBUFFER_HANDLE, PylonBuffer<Byte>> pair in image_buffers)
            {
                pair.Value.Dispose();
            }
            image_buffers.Clear();

            Pylon.StreamGrabberSetMaxNumBuffer(stream_grabber_handle, image_buffer_count);

            uint payloadSize = checked((uint)Pylon.DeviceGetIntegerFeature(device_handle, "PayloadSize"));
            Pylon.StreamGrabberSetMaxBufferSize(stream_grabber_handle, payloadSize);

            Pylon.StreamGrabberPrepareGrab(stream_grabber_handle);

            for (uint i = 0; i < image_buffer_count; ++i)
            {
                PylonBuffer<Byte> buffer = new PylonBuffer<byte>(payloadSize, true);
                PYLON_STREAMBUFFER_HANDLE handle = Pylon.StreamGrabberRegisterBuffer(stream_grabber_handle, ref buffer);
                image_buffers.Add(handle, buffer);
            }
            foreach (KeyValuePair<PYLON_STREAMBUFFER_HANDLE, PylonBuffer<Byte>> pair in image_buffers)
            {
                Pylon.StreamGrabberQueueBuffer(stream_grabber_handle, pair.Key, 0);
            }
        }

        private void CleanupGrab()
        {
            try
            {
                if (IsOpen())
                {
                    Pylon.StreamGrabberCancelGrab(stream_grabber_handle);

                    lock (lock_object)
                    {
                        bool isReady; /* Used as an output parameter. */
                        do
                        {
                            PylonGrabResult_t grabResult;  /* Stores the result of a grab operation. */
                            isReady = Pylon.StreamGrabberRetrieveResult(stream_grabber_handle, out grabResult);

                        } while (isReady);
                    }

                    foreach (KeyValuePair<PYLON_STREAMBUFFER_HANDLE, PylonBuffer<Byte>> pair in image_buffers)
                    {
                        Pylon.StreamGrabberDeregisterBuffer(stream_grabber_handle, pair.Key);
                    }

                    foreach (KeyValuePair<PYLON_STREAMBUFFER_HANDLE, PylonBuffer<Byte>> pair in image_buffers)
                    {
                        pair.Value.Dispose();
                    }
                    image_buffers.Clear();

                    Pylon.StreamGrabberFinishGrab(stream_grabber_handle);
                }
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
            }
        }

        public new void Close()
        {
            if (IsOpen())
            {
                try
                {
                    Pylon.StreamGrabberClose(stream_grabber_handle);
                    stream_grabber_handle.SetInvalid();

                    DevClose();
                }
                catch (Exception ex)
                {
                    Trace.WriteLine(ex.Message);
                }
            }
        }

        public delegate void OnImageGrabbedEventDelegate(int index, Bitmap image);
        public OnImageGrabbedEventDelegate OnImageGrabbed;
        public void OnImageGrabbedEvent(int index, Bitmap image)
        {
            if (OnImageGrabbed != null)
            {
                OnImageGrabbed(index, image);
            }
        }

        private Bitmap RawToBitmap(byte[] raw, int width, int height)
        {
            Bitmap res = new Bitmap(width, height, PixelFormat.Format24bppRgb);
            BitmapData data
            = res.LockBits(new Rectangle(0, 0, width, height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);

            IntPtr ptr = data.Scan0;
            Marshal.Copy(raw, 0, ptr, width * height * 3);
            res.UnlockBits(data);

            return res;
        }

        ColorConvertor convertor = new ColorConvertor();

        private void GrabThreadFunction()
        {
            grab_thread_continue = true;

            try
            {
                while (grab_thread_continue)
                {
                    if (!Pylon.WaitObjectWait(wait_object_handle, 200))
                    {
                        continue;
                    }

                    PylonGrabResult_t pylon_grab_result;

                    if (!Pylon.StreamGrabberRetrieveResult(stream_grabber_handle, out pylon_grab_result))
                    {
                        throw new Exception("Failed to retrieve a grab result.");
                    }

                    switch (pylon_grab_result.Status)
                    {
                        case EPylonGrabStatus.Grabbed:
                            lock (lock_object)
                            {
                                PylonBuffer<Byte> buffer = null;
                                PylonBuffer<Byte> color_buffer = null;

                                if (!image_buffers.TryGetValue(pylon_grab_result.hBuffer, out buffer))
                                    throw new Exception("Failed to find the buffer associated with the handle returned in grab result.");

                                if (buffer.Array.Length > 0)
                                {
                                    
                                    convertor.SetOutputPixelFormat(EPylonPixelType.PixelType_BGR8packed);
                                    convertor.Convert(ref color_buffer, buffer, pylon_grab_result.PixelType, (uint)pylon_grab_result.SizeX, (uint)pylon_grab_result.SizeY, (uint)pylon_grab_result.PaddingX, EPylonImageOrientation.ImageOrientation_TopDown);
                                    //Bitmap image = new Bitmap(pylon_grab_result.SizeX, pylon_grab_result.SizeY, pylon_grab_result.SizeX * 3, System.Drawing.Imaging.PixelFormat.Format24bppRgb, color_buffer.Pointer);
                                    Bitmap image = RawToBitmap(color_buffer.Array, pylon_grab_result.SizeX, pylon_grab_result.SizeY);
                                    
                                    int end = DateTime.Now.Millisecond;

                                    if (grab_thread_continue)
                                        OnImageGrabbedEvent(index, image);

                                    color_buffer.Dispose();
                                }

                                Pylon.StreamGrabberQueueBuffer(stream_grabber_handle, pylon_grab_result.hBuffer, 0);
                            }
                            break;

                        //case EPylonGrabStatus.Failed:
                        //    //Log.Out(class_name, "GrabThreadFunction()", "EPylonGrabStatus.Failed");
                        //    break;

                        //case EPylonGrabStatus.Canceled:
                        //    //Log.Out(class_name, "GrabThreadFunction()", "EPylonGrabStatus.Canceled");
                        //    break;

                        //case EPylonGrabStatus.Idle:
                        //    //Log.Out(class_name, "GrabThreadFunction()", "EPylonGrabStatus.Idle");
                        //    break;

                        //case EPylonGrabStatus.Queued:
                        //    //Log.Out(class_name, "GrabThreadFunction()", "EPylonGrabStatus.Queued");
                        //    break;

                        //case EPylonGrabStatus.UndefinedGrabStatus:
                        //    //Log.Out(class_name, "GrabThreadFunction()", "EPylonGrabStatus.UndefinedGrabStatus");
                        //    break;
                    }

                }
                Trace.WriteLine(string.Format("1. Grab Continue : {0}", grab_thread_continue));
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
            }
            finally
            {
                CleanupGrab();
            }
            

            grab_thread_continue = false;
        }

        public void GrabStop()
        {
            if (grab_thread != null && grab_thread_continue == true)
            {
                grab_thread_continue = false;
                if (!grab_thread.Join(100))
                {
                    Trace.WriteLine(string.Format("{0} : Abort", index));
                    grab_thread.Abort();
                }
                grab_thread.Join();
            }
        }

        /* for StreamGrabber                                                             */
        /*********************************************************************************/




        /*********************************************************************************/
        /*  */

        public static void PylonOpen()
        {
            Environment.SetEnvironmentVariable("PYLON_GIGE_HEARTBEAT", "500" /*ms*/);
            Pylon.Initialize();
        }

        public static void PylonClose()
        {
            Pylon.Terminate();
        }

        private static List<DeviceInfo> device_list = new List<DeviceInfo>();

        public static void Discovery()
        {
            device_list.Clear();
            uint device_count = 0;

            device_count = Pylon.EnumerateDevices();

            for (uint i = 0; i < device_count; i++)
            {
                PYLON_DEVICE_INFO_HANDLE handle = Pylon.GetDeviceInfoHandle(i);
                Hashtable device_properties = new Hashtable();
                uint device_property_count = Pylon.DeviceInfoGetNumProperties(handle);

                for (uint j = 0; j < device_property_count; j++)
                {
                    string property_key = Pylon.DeviceInfoGetPropertyName(handle, j);
                    string property_value = Pylon.DeviceInfoGetPropertyValueByIndex(handle, j);
                    device_properties.Add(property_key, property_value);
                }
                device_list.Add(new DeviceInfo(device_properties));
            }
        }

        /*  */
        /*********************************************************************************/
    }

    public class DeviceInfo
    {
        private readonly Hashtable device_properties;
        public string GetPropertyByName(string property)
        {
            string res = string.Empty;

            if (device_properties != null)
                res = device_properties[property] as string;

            return res;
        }

        public DeviceInfo(Hashtable properties)
        {
            device_properties = properties;
        }
    }

    public class ColorConvertor
    {
        PYLON_IMAGE_FORMAT_CONVERTER_HANDLE handle;

        public ColorConvertor()
        {
            handle = Pylon.ImageFormatConverterCreate();
        }

        ~ColorConvertor()
        {
            Pylon.ImageFormatConverterDestroy(handle);
        }

        public bool Convert<T>(ref PylonBuffer<T> targetBuffer, PylonBuffer<T> sourceBuffer, EPylonPixelType sourcePixelType, uint sourceWidth, uint sourceHeight, uint sourcePaddingX, EPylonImageOrientation sourceOrientation)
        {
            bool res = false;

            try
            {
                Pylon.ImageFormatConverterConvert(handle, ref targetBuffer, sourceBuffer, sourcePixelType, sourceWidth, sourceHeight, sourcePaddingX, sourceOrientation);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
            }

            return res;
        }

        public void SetOutputPixelFormat(EPylonPixelType dstPixelType)
        {
            Pylon.ImageFormatConverterSetOutputPixelFormat(handle, dstPixelType);
        }
    }
}
