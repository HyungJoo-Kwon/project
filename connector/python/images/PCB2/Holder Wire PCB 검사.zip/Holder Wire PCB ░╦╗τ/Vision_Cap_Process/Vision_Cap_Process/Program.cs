﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Vision_Cap_Process
{
    static class Program
    {
        /// <summary>
        /// 해당 응용 프로그램의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            if (ProcessChecker.IsOnlyProcess("Program Window Text"))
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new FORM_MAIN_PROCESS());
            }

            ////중복 실행 방지 코드
            //bool isCreatedNew;
            //System.Threading.Mutex mutex = new System.Threading.Mutex(true, Application.ProductName, out isCreatedNew);

            //if (isCreatedNew)
            //{
            //    Application.EnableVisualStyles();
            //    Application.SetCompatibleTextRenderingDefault(false);
            //    Application.Run(new FORM_MAIN_PROCESS());
            //    mutex.ReleaseMutex();
            //}

            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new FORM_MAIN_PROCESS());            

        }
    }
}
