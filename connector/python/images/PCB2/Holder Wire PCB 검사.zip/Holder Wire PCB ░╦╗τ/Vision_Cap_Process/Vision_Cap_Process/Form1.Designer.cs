﻿namespace Vision_Cap_Process
{
    partial class FORM_MAIN_PROCESS
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PB_MAINVIEW = new System.Windows.Forms.PictureBox();
            this.BTN_CAMERA_START = new System.Windows.Forms.Button();
            this.BTN_CAMERA_STOP = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.TB_LEDVALUE_2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BTN_SP_LEDOFF2 = new System.Windows.Forms.Button();
            this.BTN_SP_LEDON2 = new System.Windows.Forms.Button();
            this.TB_LEDVALUE = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.BTN_SP_LEDOFF1 = new System.Windows.Forms.Button();
            this.BTN_SP_LEDON1 = new System.Windows.Forms.Button();
            this.BTN_SP_DISCONNECT = new System.Windows.Forms.Button();
            this.BTN_SP_CONNECT = new System.Windows.Forms.Button();
            this.BTN_SP_SAVE = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CB_HANDSHAKING = new System.Windows.Forms.ComboBox();
            this.CB_PARITY = new System.Windows.Forms.ComboBox();
            this.CB_BAUDRATE = new System.Windows.Forms.ComboBox();
            this.CB_STOPBIT = new System.Windows.Forms.ComboBox();
            this.CB_DATABIT = new System.Windows.Forms.ComboBox();
            this.CB_COMPORT = new System.Windows.Forms.ComboBox();
            this.SP_MAINPORT = new System.IO.Ports.SerialPort(this.components);
            this.BTN_IMAGE_SAVE = new System.Windows.Forms.Button();
            this.BTN_IMAGE_LOAD = new System.Windows.Forms.Button();
            this.LB_MOUSEPOINT = new System.Windows.Forms.Label();
            this.BTN_TEST1 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.Opencv_Make_Ref = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.PB_MAINVIEW)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // PB_MAINVIEW
            // 
            this.PB_MAINVIEW.Location = new System.Drawing.Point(12, 12);
            this.PB_MAINVIEW.Name = "PB_MAINVIEW";
            this.PB_MAINVIEW.Size = new System.Drawing.Size(1292, 971);
            this.PB_MAINVIEW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PB_MAINVIEW.TabIndex = 0;
            this.PB_MAINVIEW.TabStop = false;
            this.PB_MAINVIEW.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PB_MAINVIEW_MouseMove);
            // 
            // BTN_CAMERA_START
            // 
            this.BTN_CAMERA_START.Location = new System.Drawing.Point(1338, 397);
            this.BTN_CAMERA_START.Name = "BTN_CAMERA_START";
            this.BTN_CAMERA_START.Size = new System.Drawing.Size(105, 57);
            this.BTN_CAMERA_START.TabIndex = 1;
            this.BTN_CAMERA_START.Text = "Camera Start";
            this.BTN_CAMERA_START.UseVisualStyleBackColor = true;
            this.BTN_CAMERA_START.Click += new System.EventHandler(this.BTN_CAMERA_START_Click);
            // 
            // BTN_CAMERA_STOP
            // 
            this.BTN_CAMERA_STOP.Location = new System.Drawing.Point(1474, 397);
            this.BTN_CAMERA_STOP.Name = "BTN_CAMERA_STOP";
            this.BTN_CAMERA_STOP.Size = new System.Drawing.Size(105, 57);
            this.BTN_CAMERA_STOP.TabIndex = 2;
            this.BTN_CAMERA_STOP.Text = "Camera Stop";
            this.BTN_CAMERA_STOP.UseVisualStyleBackColor = true;
            this.BTN_CAMERA_STOP.Click += new System.EventHandler(this.BTN_CAMERA_STOP_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(1338, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(524, 350);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Bisque;
            this.tabPage1.Controls.Add(this.TB_LEDVALUE_2);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.BTN_SP_LEDOFF2);
            this.tabPage1.Controls.Add(this.BTN_SP_LEDON2);
            this.tabPage1.Controls.Add(this.TB_LEDVALUE);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.BTN_SP_LEDOFF1);
            this.tabPage1.Controls.Add(this.BTN_SP_LEDON1);
            this.tabPage1.Controls.Add(this.BTN_SP_DISCONNECT);
            this.tabPage1.Controls.Add(this.BTN_SP_CONNECT);
            this.tabPage1.Controls.Add(this.BTN_SP_SAVE);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.CB_HANDSHAKING);
            this.tabPage1.Controls.Add(this.CB_PARITY);
            this.tabPage1.Controls.Add(this.CB_BAUDRATE);
            this.tabPage1.Controls.Add(this.CB_STOPBIT);
            this.tabPage1.Controls.Add(this.CB_DATABIT);
            this.tabPage1.Controls.Add(this.CB_COMPORT);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(516, 324);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Serial 통신";
            // 
            // TB_LEDVALUE_2
            // 
            this.TB_LEDVALUE_2.Font = new System.Drawing.Font("굴림", 11F);
            this.TB_LEDVALUE_2.Location = new System.Drawing.Point(183, 225);
            this.TB_LEDVALUE_2.Name = "TB_LEDVALUE_2";
            this.TB_LEDVALUE_2.Size = new System.Drawing.Size(60, 24);
            this.TB_LEDVALUE_2.TabIndex = 26;
            this.TB_LEDVALUE_2.Text = "100";
            this.TB_LEDVALUE_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TB_LEDVALUE_2.TextChanged += new System.EventHandler(this.TB_LEDVALUE_2_TextChanged);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("굴림", 11F);
            this.label8.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label8.Location = new System.Drawing.Point(55, 226);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(123, 21);
            this.label8.TabIndex = 27;
            this.label8.Text = "BOTTOM Light :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BTN_SP_LEDOFF2
            // 
            this.BTN_SP_LEDOFF2.Font = new System.Drawing.Font("굴림", 11F);
            this.BTN_SP_LEDOFF2.Location = new System.Drawing.Point(306, 225);
            this.BTN_SP_LEDOFF2.Name = "BTN_SP_LEDOFF2";
            this.BTN_SP_LEDOFF2.Size = new System.Drawing.Size(50, 25);
            this.BTN_SP_LEDOFF2.TabIndex = 25;
            this.BTN_SP_LEDOFF2.Text = "OFF";
            this.BTN_SP_LEDOFF2.UseVisualStyleBackColor = true;
            this.BTN_SP_LEDOFF2.Click += new System.EventHandler(this.BTN_SP_LEDOFF2_Click);
            // 
            // BTN_SP_LEDON2
            // 
            this.BTN_SP_LEDON2.Font = new System.Drawing.Font("굴림", 11F);
            this.BTN_SP_LEDON2.Location = new System.Drawing.Point(249, 225);
            this.BTN_SP_LEDON2.Name = "BTN_SP_LEDON2";
            this.BTN_SP_LEDON2.Size = new System.Drawing.Size(50, 25);
            this.BTN_SP_LEDON2.TabIndex = 24;
            this.BTN_SP_LEDON2.Text = "ON";
            this.BTN_SP_LEDON2.UseVisualStyleBackColor = true;
            this.BTN_SP_LEDON2.Click += new System.EventHandler(this.BTN_SP_LEDON2_Click);
            // 
            // TB_LEDVALUE
            // 
            this.TB_LEDVALUE.Font = new System.Drawing.Font("굴림", 11F);
            this.TB_LEDVALUE.Location = new System.Drawing.Point(184, 196);
            this.TB_LEDVALUE.Name = "TB_LEDVALUE";
            this.TB_LEDVALUE.Size = new System.Drawing.Size(60, 24);
            this.TB_LEDVALUE.TabIndex = 17;
            this.TB_LEDVALUE.Text = "100";
            this.TB_LEDVALUE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.TB_LEDVALUE.TextChanged += new System.EventHandler(this.TB_LEDVALUE_TextChanged);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("굴림", 11F);
            this.label7.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label7.Location = new System.Drawing.Point(68, 196);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 21);
            this.label7.TabIndex = 19;
            this.label7.Text = "TOP LIGHT :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BTN_SP_LEDOFF1
            // 
            this.BTN_SP_LEDOFF1.Font = new System.Drawing.Font("굴림", 11F);
            this.BTN_SP_LEDOFF1.Location = new System.Drawing.Point(306, 196);
            this.BTN_SP_LEDOFF1.Name = "BTN_SP_LEDOFF1";
            this.BTN_SP_LEDOFF1.Size = new System.Drawing.Size(50, 25);
            this.BTN_SP_LEDOFF1.TabIndex = 16;
            this.BTN_SP_LEDOFF1.Text = "OFF";
            this.BTN_SP_LEDOFF1.UseVisualStyleBackColor = true;
            this.BTN_SP_LEDOFF1.Click += new System.EventHandler(this.BTN_SP_LEDOFF1_Click);
            // 
            // BTN_SP_LEDON1
            // 
            this.BTN_SP_LEDON1.Font = new System.Drawing.Font("굴림", 11F);
            this.BTN_SP_LEDON1.Location = new System.Drawing.Point(250, 196);
            this.BTN_SP_LEDON1.Name = "BTN_SP_LEDON1";
            this.BTN_SP_LEDON1.Size = new System.Drawing.Size(50, 25);
            this.BTN_SP_LEDON1.TabIndex = 15;
            this.BTN_SP_LEDON1.Text = "ON";
            this.BTN_SP_LEDON1.UseVisualStyleBackColor = true;
            this.BTN_SP_LEDON1.Click += new System.EventHandler(this.BTN_SP_LEDON1_Click);
            // 
            // BTN_SP_DISCONNECT
            // 
            this.BTN_SP_DISCONNECT.Font = new System.Drawing.Font("굴림", 11F);
            this.BTN_SP_DISCONNECT.Location = new System.Drawing.Point(372, 108);
            this.BTN_SP_DISCONNECT.Name = "BTN_SP_DISCONNECT";
            this.BTN_SP_DISCONNECT.Size = new System.Drawing.Size(80, 60);
            this.BTN_SP_DISCONNECT.TabIndex = 14;
            this.BTN_SP_DISCONNECT.Text = "해제";
            this.BTN_SP_DISCONNECT.UseVisualStyleBackColor = true;
            this.BTN_SP_DISCONNECT.Click += new System.EventHandler(this.BTN_SP_DISCONNECT_Click);
            // 
            // BTN_SP_CONNECT
            // 
            this.BTN_SP_CONNECT.Font = new System.Drawing.Font("굴림", 11F);
            this.BTN_SP_CONNECT.Location = new System.Drawing.Point(372, 31);
            this.BTN_SP_CONNECT.Name = "BTN_SP_CONNECT";
            this.BTN_SP_CONNECT.Size = new System.Drawing.Size(80, 60);
            this.BTN_SP_CONNECT.TabIndex = 13;
            this.BTN_SP_CONNECT.Text = "연결";
            this.BTN_SP_CONNECT.UseVisualStyleBackColor = true;
            this.BTN_SP_CONNECT.Click += new System.EventHandler(this.BTN_SP_CONNECT_Click);
            // 
            // BTN_SP_SAVE
            // 
            this.BTN_SP_SAVE.Font = new System.Drawing.Font("굴림", 11F);
            this.BTN_SP_SAVE.Location = new System.Drawing.Point(372, 254);
            this.BTN_SP_SAVE.Name = "BTN_SP_SAVE";
            this.BTN_SP_SAVE.Size = new System.Drawing.Size(80, 60);
            this.BTN_SP_SAVE.TabIndex = 12;
            this.BTN_SP_SAVE.Text = "SAVE";
            this.BTN_SP_SAVE.UseVisualStyleBackColor = true;
            this.BTN_SP_SAVE.Click += new System.EventHandler(this.BTN_SP_SAVE_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("굴림", 11F);
            this.label6.Location = new System.Drawing.Point(51, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Handshaking :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("굴림", 11F);
            this.label5.Location = new System.Drawing.Point(78, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Parity :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("굴림", 11F);
            this.label4.Location = new System.Drawing.Point(78, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "BaudRete :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("굴림", 11F);
            this.label3.Location = new System.Drawing.Point(78, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "StopBit :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("굴림", 11F);
            this.label2.Location = new System.Drawing.Point(78, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "DataBit :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("굴림", 11F);
            this.label1.Location = new System.Drawing.Point(78, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Comport :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CB_HANDSHAKING
            // 
            this.CB_HANDSHAKING.Font = new System.Drawing.Font("굴림", 11F);
            this.CB_HANDSHAKING.FormattingEnabled = true;
            this.CB_HANDSHAKING.Items.AddRange(new object[] {
            "none"});
            this.CB_HANDSHAKING.Location = new System.Drawing.Point(184, 161);
            this.CB_HANDSHAKING.Name = "CB_HANDSHAKING";
            this.CB_HANDSHAKING.Size = new System.Drawing.Size(121, 23);
            this.CB_HANDSHAKING.TabIndex = 5;
            // 
            // CB_PARITY
            // 
            this.CB_PARITY.Font = new System.Drawing.Font("굴림", 11F);
            this.CB_PARITY.FormattingEnabled = true;
            this.CB_PARITY.Items.AddRange(new object[] {
            "none"});
            this.CB_PARITY.Location = new System.Drawing.Point(184, 135);
            this.CB_PARITY.Name = "CB_PARITY";
            this.CB_PARITY.Size = new System.Drawing.Size(121, 23);
            this.CB_PARITY.TabIndex = 4;
            // 
            // CB_BAUDRATE
            // 
            this.CB_BAUDRATE.Font = new System.Drawing.Font("굴림", 11F);
            this.CB_BAUDRATE.FormattingEnabled = true;
            this.CB_BAUDRATE.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "1800",
            "2400",
            "4800",
            "7200",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.CB_BAUDRATE.Location = new System.Drawing.Point(184, 109);
            this.CB_BAUDRATE.Name = "CB_BAUDRATE";
            this.CB_BAUDRATE.Size = new System.Drawing.Size(121, 23);
            this.CB_BAUDRATE.TabIndex = 3;
            // 
            // CB_STOPBIT
            // 
            this.CB_STOPBIT.Font = new System.Drawing.Font("굴림", 11F);
            this.CB_STOPBIT.FormattingEnabled = true;
            this.CB_STOPBIT.Items.AddRange(new object[] {
            "1",
            "2"});
            this.CB_STOPBIT.Location = new System.Drawing.Point(184, 83);
            this.CB_STOPBIT.Name = "CB_STOPBIT";
            this.CB_STOPBIT.Size = new System.Drawing.Size(121, 23);
            this.CB_STOPBIT.TabIndex = 2;
            // 
            // CB_DATABIT
            // 
            this.CB_DATABIT.Font = new System.Drawing.Font("굴림", 11F);
            this.CB_DATABIT.FormattingEnabled = true;
            this.CB_DATABIT.Items.AddRange(new object[] {
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.CB_DATABIT.Location = new System.Drawing.Point(184, 57);
            this.CB_DATABIT.Name = "CB_DATABIT";
            this.CB_DATABIT.Size = new System.Drawing.Size(121, 23);
            this.CB_DATABIT.TabIndex = 1;
            // 
            // CB_COMPORT
            // 
            this.CB_COMPORT.Font = new System.Drawing.Font("굴림", 11F);
            this.CB_COMPORT.FormattingEnabled = true;
            this.CB_COMPORT.Items.AddRange(new object[] {
            "Com1",
            "Com2",
            "Com3",
            "Com4",
            "Com5",
            "Com6",
            "Com7",
            "Com8",
            "Com9"});
            this.CB_COMPORT.Location = new System.Drawing.Point(184, 31);
            this.CB_COMPORT.Name = "CB_COMPORT";
            this.CB_COMPORT.Size = new System.Drawing.Size(121, 23);
            this.CB_COMPORT.TabIndex = 0;
            // 
            // BTN_IMAGE_SAVE
            // 
            this.BTN_IMAGE_SAVE.Location = new System.Drawing.Point(1338, 490);
            this.BTN_IMAGE_SAVE.Name = "BTN_IMAGE_SAVE";
            this.BTN_IMAGE_SAVE.Size = new System.Drawing.Size(105, 57);
            this.BTN_IMAGE_SAVE.TabIndex = 5;
            this.BTN_IMAGE_SAVE.Text = "Image Save";
            this.BTN_IMAGE_SAVE.UseVisualStyleBackColor = true;
            this.BTN_IMAGE_SAVE.Click += new System.EventHandler(this.BTN_IMAGE_SAVE_Click);
            // 
            // BTN_IMAGE_LOAD
            // 
            this.BTN_IMAGE_LOAD.Location = new System.Drawing.Point(1474, 490);
            this.BTN_IMAGE_LOAD.Name = "BTN_IMAGE_LOAD";
            this.BTN_IMAGE_LOAD.Size = new System.Drawing.Size(105, 57);
            this.BTN_IMAGE_LOAD.TabIndex = 6;
            this.BTN_IMAGE_LOAD.Text = "Image Load";
            this.BTN_IMAGE_LOAD.UseVisualStyleBackColor = true;
            this.BTN_IMAGE_LOAD.Click += new System.EventHandler(this.BTN_IMAGE_LOAD_Click);
            // 
            // LB_MOUSEPOINT
            // 
            this.LB_MOUSEPOINT.AutoSize = true;
            this.LB_MOUSEPOINT.Location = new System.Drawing.Point(12, 990);
            this.LB_MOUSEPOINT.Name = "LB_MOUSEPOINT";
            this.LB_MOUSEPOINT.Size = new System.Drawing.Size(76, 12);
            this.LB_MOUSEPOINT.TabIndex = 8;
            this.LB_MOUSEPOINT.Text = "Mouse Point";
            this.LB_MOUSEPOINT.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // BTN_TEST1
            // 
            this.BTN_TEST1.Location = new System.Drawing.Point(1338, 646);
            this.BTN_TEST1.Name = "BTN_TEST1";
            this.BTN_TEST1.Size = new System.Drawing.Size(105, 57);
            this.BTN_TEST1.TabIndex = 10;
            this.BTN_TEST1.Text = "TEST1";
            this.BTN_TEST1.UseVisualStyleBackColor = true;
            this.BTN_TEST1.Click += new System.EventHandler(this.BTN_TEST1_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(1338, 739);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(79, 16);
            this.checkBox2.TabIndex = 12;
            this.checkBox2.Text = "Gray 저장";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // Opencv_Make_Ref
            // 
            this.Opencv_Make_Ref.Location = new System.Drawing.Point(1474, 646);
            this.Opencv_Make_Ref.Name = "Opencv_Make_Ref";
            this.Opencv_Make_Ref.Size = new System.Drawing.Size(105, 57);
            this.Opencv_Make_Ref.TabIndex = 13;
            this.Opencv_Make_Ref.Text = "Make_Ref";
            this.Opencv_Make_Ref.UseVisualStyleBackColor = true;
            this.Opencv_Make_Ref.Click += new System.EventHandler(this.Opencv_Make_Ref_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FORM_MAIN_PROCESS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 1022);
            this.Controls.Add(this.Opencv_Make_Ref);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.BTN_TEST1);
            this.Controls.Add(this.LB_MOUSEPOINT);
            this.Controls.Add(this.BTN_IMAGE_LOAD);
            this.Controls.Add(this.BTN_IMAGE_SAVE);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.BTN_CAMERA_STOP);
            this.Controls.Add(this.BTN_CAMERA_START);
            this.Controls.Add(this.PB_MAINVIEW);
            this.Name = "FORM_MAIN_PROCESS";
            this.Text = "CAP Process";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FORM_MAIN_PROCESS_FormClosed);
            this.Load += new System.EventHandler(this.FORM_MAIN_PROCESS_FormLoad);
            ((System.ComponentModel.ISupportInitialize)(this.PB_MAINVIEW)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox PB_MAINVIEW;
        private System.Windows.Forms.Button BTN_CAMERA_START;
        private System.Windows.Forms.Button BTN_CAMERA_STOP;
        private System.Windows.Forms.TabControl tabControl1;
        private System.IO.Ports.SerialPort SP_MAINPORT;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox TB_LEDVALUE;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BTN_SP_LEDOFF1;
        private System.Windows.Forms.Button BTN_SP_LEDON1;
        private System.Windows.Forms.Button BTN_SP_DISCONNECT;
        private System.Windows.Forms.Button BTN_SP_CONNECT;
        private System.Windows.Forms.Button BTN_SP_SAVE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CB_HANDSHAKING;
        private System.Windows.Forms.ComboBox CB_PARITY;
        private System.Windows.Forms.ComboBox CB_BAUDRATE;
        private System.Windows.Forms.ComboBox CB_STOPBIT;
        private System.Windows.Forms.ComboBox CB_DATABIT;
        private System.Windows.Forms.ComboBox CB_COMPORT;
        private System.Windows.Forms.Button BTN_IMAGE_SAVE;
        private System.Windows.Forms.Button BTN_IMAGE_LOAD;
        private System.Windows.Forms.Label LB_MOUSEPOINT;
        private System.Windows.Forms.Button BTN_TEST1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button Opencv_Make_Ref;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox TB_LEDVALUE_2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button BTN_SP_LEDOFF2;
        private System.Windows.Forms.Button BTN_SP_LEDON2;
    }
}

